import { __ } from '@wordpress/i18n';


export default function ButtonClick({buttonText, buttonClick}) {
    return (
        <>
            <button className="recomb_button" onClick={buttonClick} type="button">
                {__(`${buttonText}`, 'recomb')}
            </button>
        </>
    )
}
