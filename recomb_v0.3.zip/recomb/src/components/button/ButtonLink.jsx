import { adminLink } from "../../utility/utility";


export default function ButtonLink({ buttonLink, buttonText}) {
    return (
        <>
            <a className="recomb_button" href={`${adminLink}?page=recomb${buttonLink}`}>
                {buttonText}
            </a>
        </>
    );
}
