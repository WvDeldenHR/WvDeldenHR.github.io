import { __ } from '@wordpress/i18n';


export default function ButtonSubmit({buttonText, disabled}) {
    return (
        <>
            <button className="recomb_button" type="submit" disabled={disabled}>
                {__(`${buttonText}`, 'recomb')}
            </button>
        </>
    )
}
