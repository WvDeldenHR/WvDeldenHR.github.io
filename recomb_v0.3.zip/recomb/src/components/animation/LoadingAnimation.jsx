function LoadingAnimation() {
    return (
        <div className="recomb_loading" role="staus" aria-live="polite">
            <span>Loading ...</span>
        </div>
    )
}

export default LoadingAnimation;
