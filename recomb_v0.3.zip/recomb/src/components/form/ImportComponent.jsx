import { useState } from '@wordpress/element';
import apiFetch from '@wordpress/api-fetch';

export default function ImportComponent() {
    const [importedData, setImportedData] = useState(null);
    const [error, setError] = useState(null);
    const [isOpen, setIsOpen] = useState(false);

    const handleFileChange = (event) => {
        setError(null);
        const file = event.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const json = JSON.parse(e.target.result);
                setImportedData(json);
            } catch {
                setError('Invalid JSON file.');
            }
        };
        reader.readAsText(file);
    };

    const handleImportConfirm = () => {
        if (!importedData) {
            alert('No data to import.');
            return;
        }

        apiFetch({
            path: '/recomb/v1/import-component',
            method: 'POST',
            data: importedData,
            }).then(() => {
                alert('Component imported successfully!');
                setImportedData(null);
            }).catch(() => {
                alert('Import failed.');
        });
    };

    const handleImportClick = () => {
        setIsOpen(true);
    };

    return (
        <div>
            <button className="recomb_button" onClick={handleImportClick}>Import</button>

            {isOpen && (
                <div className="recomb_modal-overlay" onClick={() => setIsOpen(false)}>
                    <div className="recomb_modal" onClick={(e) => e.stopPropagation()}>
                        <div className="recomb_modal-header">
                            <h2>Import Component</h2>

                            <button className="recomb_modal-button" onClick={() => setIsOpen(false)}>
                                x
                            </button>
                        </div>

                        {error && <p style={{ color: 'red' }}>{error}</p>}
                       
                        <div className="recomb_modal-input">
                            <input type="file" accept=".json,application/json" onChange={handleFileChange} />
                        </div>
                       
    
                        {importedData && (
                            <div className="recomb_button-end">
                            {/* <pre style={{ whiteSpace: 'pre-wrap', maxHeight: '300px', overflowY: 'auto', backgroundColor: '#eee', padding: '1em' }}>
                                {JSON.stringify(importedData, null, 2)}
                            </pre> */}
                                <button className="recomb_button" onClick={handleImportConfirm}>Import Component</button>
                            </div>
                        )}
                    </div>
                </div>
            )}
        </div>
    );
}
