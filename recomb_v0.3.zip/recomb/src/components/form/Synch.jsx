import { useState, useEffect } from '@wordpress/element';
import apiFetch from '@wordpress/api-fetch';

export default function Synch() {
    const [lastSync, setLastSync] = useState(null);
    const [components, setComponents] = useState([]);
    const [isSyncing, setIsSyncing] = useState(false);

    // Step 1: Fetch all components from templates (.html files)
    const fetchAllTemplates = () => {
        return apiFetch({
            path: '/recomb/v1/extract-all-templates',
            method: 'GET',
        });
    };

    // Step 2: Optionally fetch current DB components to compare (you need to implement this API)
    const fetchDbComponents = () => {
        return apiFetch({
            path: '/recomb/v1/get-all-components',
            method: 'GET',
        });
    };

    // Step 3: Sync all or only changed components
    const syncComponents = (toSyncComponents) => {
        // For simplicity, sync one by one here; you could optimize with batch API
        return Promise.all(
            toSyncComponents.map(({ component_name, template_code }) =>
                apiFetch({
                    path: '/recomb/v1/sync-template',
                    method: 'POST',
                    data: { component_name, template_code },
                })
            )
        );
    };

    const handleSync = async () => {
        setIsSyncing(true);

        try {
            const templates = await fetchAllTemplates();
            const dbComponents = await fetchDbComponents();

            // Simple comparison: filter templates where code differs or new components
            const toSync = templates.filter(template => {
                const dbComp = dbComponents.find(dc => dc.component_name === template.component_name);
                return !dbComp || dbComp.template_code !== template.template_code;
            });

            if (toSync.length === 0) {
                alert('All components are already up to date!');
                setIsSyncing(false);
                return;
            }

            await syncComponents(toSync);

            const now = new Date();
            setLastSync(now);
            localStorage.setItem('recomb_last_sync', now.toISOString());
            alert(`Synced ${toSync.length} component(s) successfully!`);
        } catch (error) {
            console.error('Sync error:', error);
            alert('Failed to sync template code');
        }

        setIsSyncing(false);
    };

    return (
        <div>
            <button className="recomb_button" onClick={handleSync} disabled={isSyncing}>
                {isSyncing ? 'Syncing...' : 'Sync Code'}
            </button>
            {lastSync && <p>Last sync: {lastSync.toLocaleString()}</p>}
        </div>
    );
}
