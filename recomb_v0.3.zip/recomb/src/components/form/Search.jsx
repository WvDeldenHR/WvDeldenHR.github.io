function Search() {
    return (
        <>
            <input className="recomb_search-input" type=""/>
        </>
    )
}

export default Search;
