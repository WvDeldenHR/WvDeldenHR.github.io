import { useState, useEffect } from 'react';
import { __ } from '@wordpress/i18n';
// Components
import LoadingAnimation from '../../animation/LoadingAnimation';


export default function TableLocation({location, setLocation}) {
    const [postTypes, setPostTypes] = useState([]);
    const [loading, setLoading] = useState(true);

    // const [error, setError] = useState(null);

    useEffect(() => {
        if (Array.isArray(window.ReCombData?.postTypes)) {
            setPostTypes(window.ReCombData.postTypes);
        } else {
            console.warn("ReCombData.postTypes is not an array", window.ReCombData?.postTypes);
        }
        setLoading(false);
    }, []);

    return (
        <>
            {loading ? (
                <LoadingAnimation />
            ) : (
                <div className="recomb_field">
                    <label htmlFor="location" className="recomb_label">{__('Show Component on', 'recomb')}:</label>

                    <select id="location" className="recomb_select" name="location" value={location} onChange={(e) => setLocation(e.target.value)}>
                        <option value="">{__('Select post type ...', 'recomb')}</option>
                        {Array.isArray(postTypes) && postTypes.length > 0 ? (
                            postTypes.map((type) => (
                                <option key={type.slug} value={type.slug}>
                                    {type.label}
                                </option>
                            ))
                        ) : (
                            <option value="">{__('No post types available', 'recomb')}</option>
                        )}
                    </select>
                </div>
            )}
        </>
    );
}
