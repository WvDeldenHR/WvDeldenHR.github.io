import { useEffect, useState } from "react";
import { adminLink } from './../../../utility/utility';
// Assets
import { ReactComponent as IconClone } from "./../../../assets/static/icons/icon_utility-clone.svg";
import { ReactComponent as IconDelete } from "./../../../assets/static/icons/icon_utility-delete.svg";
import { ReactComponent as IconEdit } from "./../../../assets/static/icons/icon_utility-edit.svg";


export default function TableComponents() {
  const [components, setComponents] = useState([]);

    useEffect(() => {
        async function fetchComponents() {
            try {
                const response = await fetch("/wp-json/recomb/v1/components", {
                    method: "GET",
                    headers: {
                        "X-WP-Nonce": ReCombData.nonce,
                    },
                });

                if (!response.ok) throw new Error("failed to fetch components");

                const data = await response.json();
                setComponents(data);
            } catch(err) {
                console.error("fail");
            }
        }
        fetchComponents();
    }, []);

    function handleDelete(id) {
        if (!window.confirm("Are you sure you want to delete this component?")) return;

        fetch(`/wp-json/recomb/v1/components/${id}`, {
            method: "DELETE",
            headers: {
            "Content-Type": "application/json",
            "X-WP-Nonce": ReCombData.nonce,
            },
        })
        .then((res) => {
        if (!res.ok) throw new Error("Delete failed");
        // Remove deleted item from state
        setComponents((prev) => prev.filter((item) => item.id !== id));
        })
        .catch((err) => {
        console.error("Delete failed", err);
        alert("Failed to delete component.");
        });
    }


    return (
        <div className="recomb_table-container">
            <div className="recomb_table recomb_table-components">
                <div className="recomb_table-row recomb_table-row-header">
                    <div className="recomb_table-column recomb_table-column-checkbox">
                        <input id="recomb-checkbox-all" className="recomb_checkbox" type="checkbox"/>
                    </div>
                    <div className="recomb_table-column recomb_table-column-title">Title</div>
                    <div className="recomb_table-column recomb_table-column-location">Location</div>
                    <div className="recomb_table-column recomb_table-column-fields">Fields</div>
                    <div className="recomb_table-column recomb_table-column-synch">Synchronized</div>
                    <div className="recomb_table-column recomb_table-column-created-by">Created By</div>
                    <div className="recomb_table-column recomb_table-column-button"></div>
                    <div className="recomb_table-column recomb_table-column-button"></div>
                    <div className="recomb_table-column recomb_table-column-button"></div>
                </div>

                {components.map((component) => (
                    <div key={component.id} className="recomb_table-row recomb_table-row-content">
                        <div className="recomb_table-column recomb_table-column-checkbox">
                            <input id={`recomb-checkbox-` + component.id} className="recomb_checkbox" type="checkbox"/>
                        </div>
                        <div className="recomb_table-column recomb_table-column-title">{component.component_label}</div>
                        <div className="recomb_table-column recomb_table-column-location">{component.location}</div>
                        <div className="recomb_table-column recomb_table-column-fields">{component.field_count}</div>
                        <div className="recomb_table-column recomb_table-column-synch"></div>
                        <div className="recomb_table-column recomb_table-column-created-by"></div>
                        <div className="recomb_table-column recomb_table-column-button">
                            <button className="recomb_table-button" type="button"
                                onClick={() => { window.location.href = `${adminLink}?page=recomb_edit_component&id=${component.id}`;}}>
                                <IconEdit />
                            </button>
                        </div>
                        <div className="recomb_table-column recomb_table-column-button">
                            <button className="recomb_table-button" type="button">
                                <IconClone />
                            </button>
                        </div>
                        <div className="recomb_table-column recomb_table-column-button">
                            <button className="recomb_table-button recomb_button-delete" type="button"
                                    onClick={() => handleDelete(component.id)}>
                                <IconDelete />
                            </button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}
