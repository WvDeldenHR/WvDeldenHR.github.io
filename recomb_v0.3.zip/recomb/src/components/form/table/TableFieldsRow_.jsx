import { __ } from '@wordpress/i18n';
import { useState } from 'react';
// Assets
import { ReactComponent as IconArrowDown } from "./../../../assets/static/icons/icon_utility-arrow-down.svg";
import { ReactComponent as IconDelete } from "./../../../assets/static/icons/icon_utility-delete.svg";
import { ReactComponent as IconClone } from "./../../../assets/static/icons/icon_utility-clone.svg";
// Components
import TableFields from "./TableFields_";
import InputField from "../input/InputField_";
import ButtonClick from "../../button/ButtonClick";


export default function TableFieldsRow({index, dispatch, depth = 0, field, onChange, handleCloneFieldRow, handleDeleteFieldRow,
    interacted = {}, fieldsInteracted, onInteracted, onError, error = {}, isLast, expandedRows, toggleExpandedRows, onDragStart, currentPath,
draggedItemPath, setDraggedItemPath, dropTargetPath, setDropTargetPath, dropType, setDropType, handleDrop, handleDragOver}) {

    const update = (key, value) => {
        onChange({ ...field, [key]: value });
        onInteracted({ ...interacted, [key]: true });
    };

    const updateField = (key, value) => {
        const updatedField = {
            ...field,
            [key]: value,
        };

        if (key === 'field_type') {
            if (value === 'component' && (!field.field_child || field.field_child.length === 0)) {
                updatedField.field_child = [{
                    field_label: '',
                    field_name: '',
                    field_type: 'text',
                    field_child: [],
                }];
            } else if (value !== 'component') {
                delete updatedField.field_child;
            }
        }

        onChange(updatedField);

        onInteracted({
            ...interacted,
            [key]: true,
        });
    };

    const [childOpenRows, setChildOpenRows] = useState(() => {
        return field.field_child?.map(() => true) || [];
    });

    const updateChildFields = (newChildFields) => {
        onChange({ ...field, field_child: newChildFields });
    };

    const updateChildErrors = (newChildErrors) => {
        onError({ ...error, field_child: newChildErrors });
    };

    const updateChildInteracted = (newChildInteracted) => {
        onInteracted({ ...interacted, field_child: newChildInteracted });
    };


    return (
        <div
              draggable
  onDragStart={() => onDragStart()}>
            <div className="recomb_table-row recomb_table-row-content">
                <div className="recomb_table-column recomb_table-column-order">
                    {index + 1}
                </div>
                <div className="recomb_table-column recomb_table-column-label">{field.field_label}</div>
                <div className="recomb_table-column recomb_table-column-name">{field.field_name}</div>
                <div className="recomb_table-column recomb_table-column-type">{field.field_type}</div>
                <div className="recomb_table-column recomb_table-column-button">
                    <button className="recomb_table-button" type="button" aria-label={__('Clone row', 'recomb')}
                        onClick={handleCloneFieldRow}>
                        <IconClone />
                    </button>
                </div>
                <div className="recomb_table-column recomb_table-column-button">
                    <button className="recomb_table-button recomb_button-delete"
                           onClick={handleDeleteFieldRow} type="button" aria-label={__('Delete row', 'recomb')}>
                        <IconDelete />
                    </button>
                </div>
                <div className="recomb_table-column recomb_table-column-button">
                    <button className={`recomb_table-button ${expandedRows ? 'img-rotate-180' : ''}`}
                            onClick={toggleExpandedRows} type="button" aria-expanded={expandedRows}>
                        <IconArrowDown />
                    </button>
                </div>
            </div>

            {expandedRows && (
                <div className={`recomb_table-field-wrapper ${isLast ? 'is-last' : ''}`}>
                    <div className="recomb_table-field">
                        <div className="recomb_field">
                            <label className="recomb_label">{__('Field Type', 'recomb')}</label>

                            <select className="recomb_select" value={field.field_type}
                                    onChange={(e) => updateField('field_type', e.target.value)}>
                                <option value="text">{__('Text', 'recomb')}</option>
                                <option value="button">{__('Button', 'recomb')}</option>
                                <option value="component">{__('Component', 'recomb')}</option>
                            </select>
                        </div>

                        <div className="recomb_field-row">
                            <InputField
                                labelText="Field Label"
                                valueText={field.field_label}
                                onChangeText={(value) => update('field_label', value)}
                                errorText={
                                (fieldsInteracted || interacted.field_label) && error.field_label
                                }
                            />
                            <InputField
                                labelText="Field Name"
                                valueText={field.field_name}
                                onChangeText={(value) => update('field_name', value)}
                                errorText={
                                (fieldsInteracted || interacted.field_name) && error.field_name
                                }
                            />
                        </div>

                        {field.field_type === 'component' && (
                                <TableFields
                                    dispatch={dispatch}
                                    fields={field.field_child || []}
                                    setFields={updateChildFields}
                                    fieldErrors={error.field_child || []}
                                    setFieldErrors={updateChildErrors}
                                    fieldInteracted={interacted.field_child || []}
                                    setFieldInteracted={updateChildInteracted}
                                    fieldsInteracted={fieldsInteracted}
                                    depth={depth + 1}
                                    openRows={childOpenRows}
                                    setOpenRows={setChildOpenRows}

                                    parentPath={currentPath}
                                    draggedItemPath={draggedItemPath}
                                    setDraggedItemPath={setDraggedItemPath}
                                    dropTargetPath={dropTargetPath}
                                    setDropTargetPath={setDropTargetPath}
                                    dropType={dropType}
                                    setDropType={setDropType}
                                    handleDrop={handleDrop}
                                    handleDragOver={handleDragOver}
                                />
                            )}

                    </div>

                    <div className="recomb_button-end">
                        <ButtonClick buttonText="Close Field" buttonClick={toggleExpandedRows} />
                    </div>
                </div>
            )}
        </div>
    );
}

