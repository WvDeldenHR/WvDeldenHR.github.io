import { __ } from '@wordpress/i18n';


export default function TableFieldsHeader() {
    return (
        <div className="recomb_table-row recomb_table-row-header">
            <div className="recomb_table-column recomb_table-column-order">#</div>
            <div className="recomb_table-column recomb_table-column-label">{__('Label', 'recomb')}</div>
            <div className="recomb_table-column recomb_table-column-name">{__('Name', 'recomb')}</div>
            <div className="recomb_table-column recomb_table-column-type">{__('Type', 'recomb')}</div>
        </div>
    );
}
