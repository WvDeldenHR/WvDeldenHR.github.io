import { useState, useRef, useCallback } from "react";
import { formFieldRowAdd, useDraggable } from "../../../utility/form";
// Components
import TableFieldsHeader from "./TableFieldsHeader";
import TableFieldsRow from "./TableFieldsRow";
import ButtonClick from "../../button/ButtonClick";


export default function TableFields({dispatch, fields = [], setFields, fieldErrors = []}) {
    // Add row
    const handleAddRow = useCallback((field_parent_id) =>
            formFieldRowAdd({ dispatch, fields, setFields }, field_parent_id),
        [dispatch, fields, setFields]
    );
    
    const findFieldErrorById = useCallback((errorsList, id) => {
        if (!errorsList) return {};
        for (const err of errorsList) {
            if (err.id === id) return err;
            if (err.field_child) {
                const childErr = findFieldErrorById(err.field_child, id);
                if (childErr) return childErr;
            }
        }
        return {};
    }, [fieldErrors]);

    const itemRefs = useRef({});
    const [dragging, setDragging] = useState(false);
    const [currentlyDraggedId, setCurrentlyDraggedId] = useState(null);

    const { handleDragOver, handleItemDrop, handleDragLeave } = useDraggable({
        items: fields, 
        setItems: setFields,
        currentlyDraggedId,
        setCurrentlyDraggedId,
        setDragging,
        itemRefs
    });

    const renderItems = useCallback((rows, level = 0, prefix = '') =>
        rows.map((item, index) => {
            const errorObj = findFieldErrorById(fieldErrors, item.id) || {};
            const currentIndex = prefix ? `${prefix}${index + 1}` : `${index + 1}`;
            const isDragged = currentlyDraggedId === item.id && dragging;

            return (
                <TableFieldsRow key={item.id} dispatch={dispatch} item={item} 
                                fields={fields} setFields={setFields} 
                                itemRefs={itemRefs} isDragged={isDragged}
                                handleItemDrop={handleItemDrop}
                                currentIndex={currentIndex} errorObj={errorObj} 
                                renderItems={renderItems} level={level} 
                                handleAddRow={handleAddRow} setDragging={setDragging}
                                setCurrentlyDraggedId={setCurrentlyDraggedId}
                                currentlyDraggedId={currentlyDraggedId}/>
            );
        }
    ));

    return (
        <div className="recomb_table recomb_table-fields">
            <TableFieldsHeader />

            <div className="recomb_table-rows"
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}>
                {renderItems(fields)}
            </div>

            <div className="recomb_button-end">
                <ButtonClick buttonText={"Add Row"} buttonClick={() => handleAddRow(null)} />
            </div> 
        </div>
    );
}
