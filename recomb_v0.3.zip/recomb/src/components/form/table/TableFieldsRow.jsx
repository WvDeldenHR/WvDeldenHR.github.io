import { useState, useCallback} from "react";
import { VALID_FIELD_TYPES } from "../../../config/constants";
import { formFieldRowClone, formFieldRowDelete, useDraggable } from "../../../utility/form";
// Assets
import { ReactComponent as IconArrowDown } from "./../../../assets/static/icons/icon_utility-arrow-down.svg";
import { ReactComponent as IconClone } from "./../../../assets/static/icons/icon_utility-clone.svg";
import { ReactComponent as IconDelete } from "./../../../assets/static/icons/icon_utility-delete.svg";
// Components
import TableFieldsHeader from "./TableFieldsHeader";
import InputSelect from "../input/InputSelect";
import InputField from "../input/InputField";
import ButtonClick from "../../button/ButtonClick";


export default function TableFieldsRow({dispatch, item, fields, setFields, itemRefs, isDragged, handleItemDrop, 
    currentIndex, errorObj, renderItems, level, handleAddRow, setDragging, setCurrentlyDraggedId, currentlyDraggedId
}) {
    const [expandedRows, setExpandedRows] = useState({});

    // Toggle row
    const toggleExpandedRows = (id) => {
        setExpandedRows(prev => ({
            ...prev,
            [id]: !prev[id],
        }));
    };

    // Clone row
    const handleCloneItem = useCallback((id) => 
            formFieldRowClone({ dispatch, fields, setFields }, id),
        [dispatch, fields, setFields]
    );

    // Delete row
    const handleDeleteRow = useCallback((id) =>
            formFieldRowDelete({ dispatch, fields, setFields}, id),
        [dispatch, fields, setFields]
    );

    const { handleDragStart, handleItemDragEnd, onDragOverItem } = useDraggable({
        items: fields, setItems: setFields, setDragging, setCurrentlyDraggedId, currentlyDraggedId, itemRefs
    })


    function handleInputChange(itemId, field, value) {
        console.log('handleInputChange triggered', { itemId, field, value });

        const updateItems = (list) => {
            return list.map(item => {
                if (item.id === itemId) {
                    const updated = { ...item, [field]: value };
                    console.log('Updated item:', updated);
                    return updated;
                }
                if (Array.isArray(item.field_child) && item.field_child.length > 0) {
                    return { ...item, field_child: updateItems(item.field_child) };
                }
                return item;
            });
        };

        try {
            const updatedFields = updateItems(fields);
            console.log('✅ Updated fields:', JSON.stringify(updatedFields, null, 2));
            setFields(updatedFields);
        } catch (err) {
            console.error('❌ Error during field update:', err);
        }
    }

    function handleTypeChange(itemId, newType) {
        const updateType = (list) =>
            list.map(item => {
                if (item.id === itemId) {
                    return { ...item, field_type: newType };
                }
                if (item.field_child && item.field_child.length > 0) {
                    return { ...item, field_child: updateType(item.field_child) };
                }
                return item;
            });

        const updatedFields = updateType(fields);
        setFields(updatedFields);
    }


    return (
        <div className={`recomb_table-row-wrapper ${isDragged ? "opacity-0" : "opacity-100"}`}
            ref={(el) => itemRefs.current[item.id] = el}>
            <div onDragOver={(e) => onDragOverItem(e, item.id)}
                onDrop={handleItemDrop}>
                <div className="recomb_table-row recomb_table-row-content">
                     <div className="recomb_table-column recomb_table-column-order"
                        draggable
                        onDragStart={(e) => handleDragStart(e, item.id)}
                        onDragEnd={handleItemDragEnd}>
                        {currentIndex}
                    </div>
                    <div className="recomb_table-column recomb_table-column-label">{item.field_label}</div>
                    <div className="recomb_table-column recomb_table-column-name">{item.field_name}</div>
                    <div className="recomb_table-column recomb_table-column-type">{item.field_type}</div>
                    <div className="recomb_table-column recomb_table-column-button">
                        <button className="recomb_table-button" type="button"
                            onClick={() => handleCloneItem(item.id)}>
                            <IconClone />
                        </button>
                    </div>
                    <div className="recomb_table-column recomb_table-column-button">
                        <button className="recomb_table-button recomb_button-delete" type="button" 
                                onClick={() => handleDeleteRow(item.id)}>
                            <IconDelete />
                        </button>
                    </div>
                    <div className="recomb_table-column recomb_table-column-button">
                        <button className={`recomb_table-button ${expandedRows[item.id] ? "img-rotate-180" : ""}`} type="button"
                                onClick={() => toggleExpandedRows(item.id)}>
                            <IconArrowDown />
                        </button>
                    </div>
                </div>
            </div>

            {expandedRows[item.id] &&
                <div className="recomb_table-field-wrapper">
                    <div className="recomb_table-field">
                        <InputSelect labelText="Field Type" name={"field-type" + item.id} value={item.field_type} 
                                    onChangeOption={(e) => handleTypeChange(item.id, e.target.value)} 
                                    optionText="Select Field Type" options={VALID_FIELD_TYPES}
                                    errors={errorObj.field_type} />

                        <div className="recomb_field-row">
                            <InputField labelText="Field Label" name={"field-label" + item.id} value={item.field_label} 
                                        onChangeText={(e) => handleInputChange(item.id, "field_label", e.target.value)}
                                        errors={errorObj.field_label} />
                            <InputField labelText="Field Name" name={"field-name" + item.id} value={item.field_name} 
                                        onChangeText={(e) => handleInputChange(item.id, "field_name", e.target.value)}
                                        errors={errorObj.field_name} />
                        </div>
                    </div>

                    {item.field_type === "component" && (
                        <div className={`${isDragged ? "opacity-0" : "opacity-100"}`}>
                            <div className="recomb_table-row-container">
                                <TableFieldsHeader />

                                {/* {renderItems(item.field_child || [], level + 1, `${currentIndex}.`)} */}
                                {Array.isArray(item.field_child) && renderItems(item.field_child, level + 1, `${currentIndex}.`)}

                            </div>

                            <div className="recomb_button-end">
                                <ButtonClick buttonText={"Add Row"} buttonClick={() => handleAddRow(item.id)}/>
                            </div>
                        </div> 
                    )}
                </div>
            }   
        </div>
    );
}
