import { useState, useEffect, useCallback, useRef } from 'react';
import { __ } from '@wordpress/i18n';
// import { addFieldRow, cloneFieldRow, deleteFieldRow} from '../../../utility/form';
// Components
import TableFieldsRow from './TableFieldsRow_';
import ButtonClick from '../../button/ButtonClick';


function DragPlaceholder({ onDrop }) {
    return (
        <div
            className="drag-placeholder"
            onDragOver={(e) => e.preventDefault()}
            onDrop={onDrop}
        />
    );
}

function DraggableRowWrapper({ index, children, onDragOver }) {
    const ref = useRef(null);

    const handleDragOver = (e) => {
        if (ref.current) {
            onDragOver(e, index, ref);
        }
    };

    return (
        <div ref={ref} onDragOver={handleDragOver}>
            {children}
        </div>
    );
}

export default function TableFields({depth = 0, dispatch, fields = [], setFields, fieldInteracted = [], fieldsInteracted, setFieldInteracted = () => {},
    fieldErrors = [], setFieldErrors = () => {}, parentPath = []}) {

    const [expandedRows, setExpandedRows] = useState(() => []);
    const [draggedItemPath, setDraggedItemPath] = useState(null);
    const [dropTargetPath, setDropTargetPath] = useState(null);
    const [dropType, setDropType] = useState(null);

    const updateFieldAtIndex = useCallback((index, updatedItem, originalList) =>
        originalList.map((item, i) => (i === index ? updatedItem : item)),
    []);

    // Add field row
    const handleAddFieldRow = useCallback(() => {
        addFieldRow({array: fields, setArray: setFields, dispatch, expandedRows, setExpandedRows});
    }, [dispatch, fields, setFields, expandedRows, setExpandedRows]);

    // Clone field row
    const handleCloneFieldRow = useCallback((index) => {
        cloneFieldRow({index, array: fields, setArray: setFields, dispatch, expandedRows, setExpandedRows});
    }, [dispatch, fields, setFields, expandedRows, setExpandedRows]);

    // Delete field row
    const handleDeleteFieldRow = useCallback((index) => {
        deleteFieldRow({index, array: fields, setArray: setFields, dispatch, expandedRows, setExpandedRows});
    }, [dispatch, fields, setFields, expandedRows, setExpandedRows]);

    // Toggle field row
    const toggleExpandedRows = useCallback((index) => {
        setExpandedRows(prev => {
            const updated = [...prev];
            updated[index] = !updated[index];
            return updated;
        });
    }, []);

    useEffect(() => {
        setExpandedRows((prev) => {
            const newLength = fields.length;
            if (prev.length === newLength) return prev;
            if (prev.length > newLength) {
                return prev.slice(0, newLength);
            }
            return [...prev, ...Array(newLength - prev.length).fill(true)];
        });
    }, [fields]);


    const getItemAtPath = (list, path) => {
        return path.reduce((acc, i) => {
            if (!acc) return undefined;
            if (Array.isArray(acc)) return acc[i];
            return acc.field_child?.[i];
        }, list);
    };
    const removeItemAtPath = (list, path) => {
        if (path.length === 1) {
            const copy = [...list];
            copy.splice(path[0], 1);
            return copy;
        }
        const [head, ...rest] = path;
        const copy = [...list];
        copy[head] = {
            ...copy[head],
            field_child: removeItemAtPath(copy[head].field_child || [], rest),
        };
        return copy;
    };
    const insertItemAtPath = (list, path, item) => {
        if (path.length === 1) {
            const copy = [...list];
            copy.splice(path[0], 0, item);
            return copy;
        }
        const [head, ...rest] = path;
        const copy = [...list];
        copy[head] = {
            ...copy[head],
            field_child: insertItemAtPath(copy[head].field_child || [], rest, item),
        };
        return copy;
    };

    const handleDragStart = (path) => {
        setDraggedItemPath(path);
    };

    const handleDragOver = (e, index, ref, path) => {
        e.preventDefault();
        const rect = ref.current.getBoundingClientRect();
        const offsetY = e.clientY - rect.top;
        const third = rect.height / 3;

        setDropTargetPath(path);
        setDropType(offsetY < third ? 'before' : offsetY > 2 * third ? 'after' : 'inside');
    };

    const handleDrop = () => {
        if (!draggedItemPath || !dropTargetPath || !dropType) return;
        const isDescendant = (ancestor, descendant) => {
        if (descendant.length <= ancestor.length) return false;
            return ancestor.every((v, i) => descendant[i] === v);
        };

        if (
            draggedItemPath.join(',') === dropTargetPath.join(',') ||
            isDescendant(draggedItemPath, dropTargetPath)
        ) {
            return;
        }

        const item = getItemAtPath(fields, draggedItemPath);
        const listWithout = removeItemAtPath(fields, draggedItemPath);

        let updated;

        if (dropType === 'inside') {
            updated = insertItemAtPath(listWithout, [...dropTargetPath, 0], item);
        } else {
            const targetPath = [...dropTargetPath];
            if (dropType === 'after') targetPath[targetPath.length - 1] += 1;
            updated = insertItemAtPath(listWithout, targetPath, item);
        }

        setFields(updated);
        setDraggedItemPath(null);
        setDropTargetPath(null);
        setDropType(null);
    };

    const renderFieldRow = (field, index) => {
    const currentPath = [...parentPath, index];
    const isLast = index === fields.length - 1;

    return (
        <DraggableRowWrapper
            key={currentPath.join('-')}
            index={index}
            onDragOver={(e, i, ref) => handleDragOver(e, i, ref, currentPath)}
        >
            {dropTargetPath?.join('-') === currentPath.join('-') && dropType === 'before' && (
                <DragPlaceholder onDrop={handleDrop} />
            )}

            <TableFieldsRow
                index={index}
                dispatch={dispatch}
                depth={depth}
                field={field}
                onChange={(updated) => setFields(updateFieldAtIndex(index, updated, fields))}
                handleCloneFieldRow={() => handleCloneFieldRow(index)}
                handleDeleteFieldRow={() => handleDeleteFieldRow(index)}
                interacted={fieldInteracted[index]}
                fieldsInteracted={fieldsInteracted}
                onInteracted={(updated) => setFieldInteracted(updateFieldAtIndex(index, updated, fieldInteracted))}
                onError={(updated) => setFieldErrors(updateFieldAtIndex(index, updated, fieldErrors))}
                error={fieldErrors[index]}
                isLast={isLast}
                expandedRows={expandedRows[index]}
                toggleExpandedRows={() => toggleExpandedRows(index)}

                onDragStart={() => handleDragStart(currentPath)}
                currentPath={currentPath}
                renderFieldRow={renderFieldRow}

                draggedItemPath={draggedItemPath}
                setDraggedItemPath={setDraggedItemPath}
                dropTargetPath={dropTargetPath}
                setDropTargetPath={setDropTargetPath}
                dropType={dropType}
                setDropType={setDropType}
                handleDrop={handleDrop}
                handleDragOver={handleDragOver}
            />

            {dropTargetPath?.join('-') === currentPath.join('-') && dropType === 'after' && (
                <DragPlaceholder onDrop={handleDrop} />
            )}
        </DraggableRowWrapper>
    );
};



    return (
        <div className="recomb_table-fields-container">
            <div className="recomb_table-fields">
                <div className="recomb_table-row recomb_table-row-header">
                    <div className="recomb_table-column recomb_table-column-order">#</div>
                    <div className="recomb_table-column recomb_table-column-label">{__('Label', 'recomb')}</div>
                    <div className="recomb_table-column recomb_table-column-name">{__('Name', 'recomb')}</div>
                    <div className="recomb_table-column recomb_table-column-type">{__('Type', 'recomb')}</div>
                    <div className="recomb_table-column recomb_table-column-button"></div>
                    <div className="recomb_table-column recomb_table-column-button"></div>
                    <div className="recomb_table-column recomb_table-column-button"></div>
                </div>
{/* 
                {fields.map((field, index) => {
                    const currentPath = [...parentPath, index];
                    const isLast = index === fields.length - 1;

                    return (
                        <DraggableRowWrapper
                            key={currentPath.join('-')}
                            index={index}
                            onDragOver={(e, i, ref) => handleDragOver(e, i, ref, currentPath)}
                        >
                            {dropTargetPath?.join('-') === currentPath.join('-') && dropType === 'before' && (
                                <DragPlaceholder onDrop={handleDrop} />
                            )}
                            <TableFieldsRow
                                index={index}
                                dispatch={dispatch}
                                depth={depth}
                                field={field}
                                onChange={(updated) => setFields(updateFieldAtIndex(index, updated, fields))}
                                handleCloneFieldRow={() => handleCloneFieldRow(index)}
                                handleDeleteFieldRow={() => handleDeleteFieldRow(index)}
                                interacted={fieldInteracted[index]}
                                fieldsInteracted={fieldsInteracted}
                                onInteracted={(updated) => setFieldInteracted(updateFieldAtIndex(index, updated, fieldInteracted))}
                                onError={(updated) => setFieldErrors(updateFieldAtIndex(index, updated, fieldErrors))}
                                error={fieldErrors[index]}
                                isLast={isLast}
                                expandedRows={expandedRows[index]}
                                toggleExpandedRows={() => toggleExpandedRows(index)}

                                onDragStart={() => handleDragStart(currentPath)}
                                currentPath={currentPath}

                            />

                            {dropTargetPath?.join('-') === currentPath.join('-') && dropType === 'after' && (
                                <DragPlaceholder onDrop={handleDrop} />
                            )}
                        </DraggableRowWrapper>
                    );
                })} */}

                {fields.map((field, index) => renderFieldRow(field, index))}

                <div className="recomb_button-end">
                    <ButtonClick buttonText="Add Field" buttonClick={handleAddFieldRow} />
                </div>
            </div>
        </div>
    );
}





import { useEffect, useState } from 'react';
import { adminLink } from '../utility/Utility';
import { __ } from '@wordpress/i18n'
// Assets
import { ReactComponent as IconClone } from './../../assets/static/icons/icon_utility-clone.svg';
import { ReactComponent as IconDelete } from './../../assets/static/icons/icon_utility-delete.svg';
import { ReactComponent as IconEdit } from './../../assets/static/icons/icon_utility-edit.svg';
// Components
import LoadingAnimation from '../animation/LoadingAnimation';


export default function Table() {
    const [components, setComponents] = useState([]);

    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');

    // Fetch Components
    useEffect(() => {
        async function fetchComponents() {
            try {
                const response = await fetch('/wp-json/recomb/v1/components');

                if (!response.ok) throw new Error(__('Failed to fetch fields', 'recomb'));

                const data = await response.json();
                setComponents(data);
            } catch (err) {
                const message = __('Could not load fields.', 'recomb');
                console.error(message, err);
                setError(message);
            } finally {
                setLoading(false);
            }
        }
        fetchComponents();
    }, []);

    // Delete Component
    const handleDelete = async (id) => {
        if (!confirm(__('Are you sure you want to delete this field?', 'recomb'))) return;

        try {
            const response = await fetch(`/wp-json/recomb/v1/fields/${id}`, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                    'X-WP-Nonce': ReCombData.nonce,
                },
            });
            if (!response.ok) throw new Error(__('Failed to delete field.', 'recomb'));

            setComponents(prev => prev.filter(component => component.id !== id));
        } catch (err) {
            console.error(__('Could not delete field.', 'recomb'), err);
            alert(__('Error deleting field.', 'recomb'));
        }
    };


    return (
        <div className="recomb_table-container">
            {loading ? (
                <LoadingAnimation />
            ) : error ? (
                <>
                    <span>{error}</span>
                </>
            ) : (
                <table className="recomb_table">
                    <thead>
                        <tr>
                            <td className="recomb_table-column recomb_table-column-checkbox">
                                <input className="recomb_checkbox" type="checkbox"/>
                            </td>
                            <th className="recomb_table-column recomb_table-column-title">{__('Title', 'recomb')}</th>
                            <th className="recomb_table-column recomb_table-column-location">{__('Location', 'recomb')}</th>
                            <th className="recomb_table-column recomb_table-column-fields">{__('Fields', 'recomb')}</th>
                            <th className="recomb_table-column recomb_table-column-synch">{__('Synchronized', 'recomb')}</th>
                            <th className="recomb_table-column recomb_table-column-button"></th>
                            <th className="recomb_table-column recomb_table-column-button"></th>
                            <th className="recomb_table-column recomb_table-column-button"></th>
                        </tr>
                    </thead>

                    {components.length === 0 ? (
                        <>
                            <span>No fields yet.</span>
                        </>
                    ) : (
                        <tbody>
                            {components.map(component => (
                                <tr key={component.id}>
                                    <td className="recomb_table-column recomb_table-column-checkbox">
                                        <input className="recomb_checkbox" type="checkbox" />
                                    </td>
                                    <td className="recomb_table-column recomb_table-column-title">
                                        {component.name}
                                    </td>
                                    <td className="recomb_table-column recomb_table-column-location"></td>
                                    <td className="recomb_table-column recomb_table-column-fields">
                                        {component.fields ? component.fields.length : 0}
                                    </td>
                                    <td className="recomb_table-column recomb_table-column-synch"></td>
                                    <td className="recomb_table-column recomb_table-column-button">
                                        <button className="recomb_table-button">
                                            <IconClone />
                                        </button>
                                    </td>
                                    <td className="recomb_table-column recomb_table-column-button">
                                        <button className="recomb_table-button" 
                                                onClick={() => { window.location.href = `${adminLink}?page=recomb_edit_component&id=${component.id}`;}}>
                                            <IconEdit />
                                        </button>
                                    </td>
                                    <td className="recomb_table-column recomb_table-column-button">
                                        <button className="recomb_table-button recomb_table-button-delete" onClick={() => handleDelete(component.id)}>
                                            <IconDelete />
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    )}
                </table>
            )}
        </div>
    )
}
