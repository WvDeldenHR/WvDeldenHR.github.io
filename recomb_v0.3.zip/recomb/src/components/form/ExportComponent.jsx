import { useState, useEffect } from '@wordpress/element';
import apiFetch from '@wordpress/api-fetch';

export default function ExportComponent() {
    const [isOpen, setIsOpen] = useState(false);
    const [components, setComponents] = useState([]);
    const [selectedComponentId, setSelectedComponentId] = useState(null);
    const [exportData, setExportData] = useState(null);

    useEffect(() => {
        if (isOpen) {
            apiFetch({ path: '/recomb/v1/components-with-fields' }).then(data => {
                setComponents(data);
            });
        }
    }, [isOpen]);

    const handleExportClick = () => {
        setIsOpen(true);
    };

    const handleExportConfirm = () => {
        if (!selectedComponentId) {
            alert('Please select a component.');
            return;
        }

        const comp = components.find(c => parseInt(c.id, 10) === parseInt(selectedComponentId, 10));
        if (!comp) {
            alert('Selected component not found.');
            return;
        }

        const json = JSON.stringify(comp, null, 2);
        setExportData(json);
        downloadJSON(`component-${comp.id}.json`, json);
    };

    
    function downloadJSON(filename, jsonData) {
        const blob = new Blob([jsonData], { type: 'application/json' });
        const url = URL.createObjectURL(blob);

        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();

        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }


    return (
        <>
            <button className="recomb_button" onClick={handleExportClick}>Export</button>

            {isOpen && (
                <div className="recomb_modal-overlay" onClick={() => setIsOpen(false)}>
                    <div className="recomb_modal" onClick={(e) => e.stopPropagation()}>
                        <div className="recomb_modal-header">
                            <h2>Export Component</h2>

                            <button className="recomb_modal-button" onClick={() => setIsOpen(false)}>
                                x
                            </button>
                        </div>
                       
                        <div className="recomb_modal-select">
                            <select value={selectedComponentId || ''}
                                    onChange={(e) => setSelectedComponentId(e.target.value)}>
                                <option value="" disabled>Select a component</option>
                                {components.map((c) => (
                                    <option key={c.id} value={c.id}>
                                        {c.component_name}
                                    </option>
                                ))}
                            </select>
                        </div>

                        <div className="recomb_button-end">
                            <button className="recomb_button" onClick={handleExportConfirm}>Export</button>
                        </div>
                    </div>
                </div>
            )}
        </>
    );
}
