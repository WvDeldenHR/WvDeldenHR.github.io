import { __ } from '@wordpress/i18n';


export default function InputSelect({labelText, name, value, onChangeOption, optionText, options = [], errors}) {
    const errorId = `${name}-error`;

    return (
        <div className="recomb_field">
            <label className="recomb_label" htmlFor={name}>{__(`${labelText}`, 'recomb')}</label>

            <select id={name} className="recomb_select" name={value} value={value} onChange={onChangeOption}
                    aria-invalid={!!errors} aria-describedby={errors ? errorId : undefined}>
                <option className="recomb_option" value="" disabled>{__(`${optionText}`, 'recomb')}</option>
                {options.map((option) => (
                    <option className="recomb_option" key={option} value={option}>{option}</option>
                ))}
            </select>

            {errors && (
                <span id={errorId} className="recomb_error" role="alert">{errors}</span>
            )}
        </div>
    );
}
