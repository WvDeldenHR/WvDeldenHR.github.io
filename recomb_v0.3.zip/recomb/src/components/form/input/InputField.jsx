import { __ } from '@wordpress/i18n';


export default function InputField({labelText, name, value, onChangeText, errors}) {
    const errorId = `${name}-error`;

    return (
        <div className="recomb_field">
            <label className="recomb_label" htmlFor={name}>{__(`${labelText}`, 'recomb')}</label>

            <input id={name} className="recomb_input" name={name} value={value} onChange={onChangeText} 
                    aria-invalid={!!errors} aria-describedby={errors ? errorId : undefined} type="text" />

            {errors && (
                <span id={errorId} className="recomb_error" role="alert">{errors}</span>
            )}
        </div>
    );
}
