import { useEffect, useState } from 'react';
import { dataGETComponent, getMetaboxData } from '../../config/api';

function buildFieldTree(fields, parentId = null) {
    return fields
        .filter(field => field.field_parent_id === parentId)
        .sort((a, b) => a.sort_order - b.sort_order)
        .map(field => ({
            ...field,
            children: buildFieldTree(fields, field.id)
        }));
}

function generateUUID() {
    return crypto.randomUUID?.() || 'tmp_' + Math.random().toString(36).substring(2, 10);
}

function collectFieldValues(fields, metaboxData) {
    const tempEntries = [];

    function walk(fields, parentTempId = null, parentId = null) {
        for (const field of fields) {
            const matches = metaboxData.filter(e => 
                e.field_id === field.id && e.parent_id === parentId
            );

            for (const entry of matches) {
                // Use DB id as stable temp_id (convert to string for safety)
                const temp_id = entry.id.toString();

                tempEntries.push({
                    ...entry,
                    temp_id,
                    parent_temp_id: parentTempId,
                });

                if (field.children?.length) {
                    walk(field.children, temp_id, entry.id);
                }
            }

            // If it's a component and nothing was found, initialize empty with a generated temp_id
            if (matches.length === 0 && field.field_type === 'component') {
                const temp_id = generateUUID();

                tempEntries.push({
                    temp_id,
                    field_id: field.id,
                    parent_temp_id: parentTempId,
                    value: '',
                    post_id: null,
                    component_id: null,
                });

                if (field.children?.length) {
                    walk(field.children, temp_id, null);
                }
            }
        }
    }

    walk(fields);

    return tempEntries;
}


function FieldRenderer({ field, collectedData, parentTempId = null, onValueChange }) {
    // Find matching entry, if any
    const matchingEntry = collectedData.find(entry =>
        entry.field_id === field.id && entry.parent_temp_id === parentTempId
    );

    // temp_id: from existing entry or generate a new one ONCE
    const [tempId] = useState(matchingEntry?.temp_id || generateUUID());
    const [value, setValue] = useState(matchingEntry?.value || '');

    // Sync changes up to parent
    useEffect(() => {
        onValueChange({
            temp_id: tempId,
            field_id: field.id,
            parent_temp_id: parentTempId,
            post_id: matchingEntry?.post_id || null,
            component_id: matchingEntry?.component_id || null,
            value,
        });
    }, [value]);

    const handleChange = (e) => {
        setValue(e.target.value);
    };

    return (
        <div className="recomb-metabox_row">
            <div className="recomb-metabox_row-header">
                <label>{field.field_label}</label>
                <span className="recomb-metabox_row-header-type">{field.field_type}</span>
            </div>

            <div className="recomb-metabox_row-content">
                {field.field_type !== 'component' && (
                    <input type="text" value={value} onChange={handleChange} />
                )}

                {field.children.length > 0 && (
                    <div>
                        {field.children.map(child => (
                            <FieldRenderer
                                key={`${child.id}-${tempId}`}
                                field={child}
                                collectedData={collectedData}
                                parentTempId={tempId}
                                onValueChange={onValueChange}
                            />
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
}


export default function Metabox({ id }) {
    const [fields, setFields] = useState([]);
    const [metaboxData, setMetaboxData] = useState([]);
    const [collectedData, setCollectedData] = useState([]);

    const postId = window.ReCombData?.postId || 0;

    const handleValueChange = (entry) => {
        setCollectedData(prev => {
            const filtered = prev.filter(e => e.temp_id !== entry.temp_id);
            return [...filtered, entry];
        });
    };

    useEffect(() => {
        if (!id || !postId) return;

        async function fetchData() {
            try {
                const [component, data] = await Promise.all([
                    dataGETComponent(id),
                    getMetaboxData(postId, id),
                ]);

                const tree = buildFieldTree(component.fields);
                const initialCollected = collectFieldValues(tree, data);

                setFields(tree);
                setMetaboxData(data);
                setCollectedData(initialCollected);
            } catch (err) {
                console.error('Error loading metabox:', err);
            }
        }

        fetchData();
    }, [id, postId]);

    return (
        <div className="recomb-metabox_container">
            <div className="recomb-metabox">
                {fields.map(field => (
                    <FieldRenderer
                        key={field.id}
                        field={field}
                        collectedData={collectedData}
                        onValueChange={handleValueChange}
                    />
                ))}

                <input
                    type="hidden"
                    name={`recomb_metabox_data[${id}]`}
                    value={JSON.stringify(collectedData)}
                />
            </div>
        </div>
    );
}
