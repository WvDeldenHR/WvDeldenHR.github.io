// Components
import Header from "../nav/Header";


export default function Layout({children}) {
    return (
        <div className="recomb_wrapper">
            <Header />

            <div className="recomb_container">
                {children}
            </div>
        </div>
    );
}
