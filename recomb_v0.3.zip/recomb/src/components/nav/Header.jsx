import { adminLink } from '../../utility/utility';
// Assets
import { ReactComponent as Logo } from './../../assets/static/logo/recomb-logo.svg';
// Components
import Nav from "./Nav";


export default function Header() {
    return (
        <header className="recomb_header" id="recomb_header">
            <a className="recomb_logo" href={`${adminLink}?page=recomb`}>
                <Logo />
            </a>

            <Nav />
        </header>
    );
}
