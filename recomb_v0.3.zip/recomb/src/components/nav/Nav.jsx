import { __ } from '@wordpress/i18n';
import { adminLink } from '../../utility/utility';


export default function Nav() {
    return (
        <nav className="recomb_nav">
            <ul className="recomb_nav-list">
                <li className="recomb_nav-item">
                    <a className="recomb_nav-link" href={`${adminLink}?page=recomb_settings`}>{__('Settings', 'recomb')}</a>
                </li>
                <li className="recomb_nav-item">
                    <a className="recomb_nav-link" href="/">{__('Account', 'recomb')}</a>
                </li>
            </ul>
        </nav>
    );
}
