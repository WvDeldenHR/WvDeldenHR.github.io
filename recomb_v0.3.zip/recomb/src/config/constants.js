export const GENERATED_ID = (() => {
    let fallbackCounter = 0;
    return () => (typeof crypto !== "undefined" && crypto.randomUUID) ? crypto.randomUUID() 
                : `_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}_${++fallbackCounter}`;
})();
export const MAX_LENGTH = 200;

// Validation
export const VALID_FIELD_TEXT = 
    (value) => typeof value === 'string' && /^[a-zA-Z_][a-zA-Z0-9_]*$/.test(value.trim());
export const VALID_FIELD_TEXT_BASIC = 
    (value) => typeof value === 'string' && /^[\w\s.,\-()'"]+$/.test(value.trim());
export const VALID_FIELD_TYPES = ['text', 'component'];
