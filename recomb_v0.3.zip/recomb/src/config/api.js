const API_BASE = '/wp-json/recomb/v1';

async function apiRequest(endpoint, method = 'GET', body = null) {
    const headers = {
        'Content-Type': 'application/json',
        'X-WP-Nonce': ReCombData.nonce,
    };

    const response = await fetch(`${API_BASE}${endpoint}`, {
        method,
        headers,
        body: body ? JSON.stringify(body) : null,
    });

    const data = await response.json();

    if (!response.ok) {
        throw new Error(data.message || 'Unknown error');
    }

    return data;
}

// Specific helpers
export const dataGET = () => apiRequest('/components', 'GET');
export const dataGETComponent = (id) => apiRequest(`/components/${id}`);
export const dataPOST = (data) => apiRequest('/components', 'POST', data);
export const dataPUT = (id, data) => apiRequest(`/components/${id}`, 'POST', data);
export const getMetaboxData = (postId, componentId) =>
  apiRequest(`/metabox-data?post_id=${postId}&component_id=${componentId}`);

