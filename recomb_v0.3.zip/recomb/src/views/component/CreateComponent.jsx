import { useState, useEffect, useReducer, useCallback } from 'react';
import { __ } from '@wordpress/i18n';
import { dataGET, dataPOST } from '../../config/api';
import { componentDefaults, componentReducer } from '../../utility/state';
import { validateComponentFields, validateComponentRowFields, formMarkFieldsInteracted, formAssignSortOrderFields } from '../../utility/form';
import { adminLink } from '../../utility/utility';
// Components
import Layout from "../../components/layout/Layout";
import TableFields from '../../components/form/table/TableFields';
import TableLocation from '../../components/form/table/TableLocation';
import ButtonSubmit from "../../components/button/ButtonSubmit";
import InputField from '../../components/form/input/InputField';
import LoadingAnimation from '../../components/animation/LoadingAnimation';


export default function ComponentCreate() {
    const [state, dispatch] = useReducer(componentReducer, componentDefaults);
    const { componentLabel, componentName, fields, location, errors, errorMessage, fieldErrors, fieldInteracted, fieldsInteracted } = state;
    const [componentNamesExist, setComponentNamesExists] = useState([]);

    useEffect(() => {
        dataGET()
            .then(components => setComponentNamesExists(components.map(c => c.component_name)))
            .catch(error => {
                console.error(`${__('Fetching existing components failed:')}`, error);
                dispatch({
                    type: 'SET_ERROR_MESSAGE',
                    payload: __('Failed to load existing component names.', 'recomb'),
                });
            });
    }, []);

    const setSubmitting = useCallback((isSubmitting) => {
        dispatch({ type: 'SET_SUBMITTING', payload: isSubmitting });
    }, []);

    const handleInputFields = useCallback((field) => (e) => {
        const value = e.target.value;
        if (field === 'componentLabel') {
            dispatch({ type: 'SET_COMPONENT_LABEL', payload: value });
        } else if (field === 'componentName') {
            dispatch({ type: 'SET_COMPONENT_NAME', payload: value });
        }
    }, []);

    const updateFields = useCallback((updatedFields) => {
        if (!Array.isArray(updatedFields)) return;
        dispatch({ type: 'SET_FIELDS', payload: updatedFields });
        dispatch({ type: 'SET_FIELD_ERRORS', payload: validateComponentRowFields(updatedFields) });
    }, []);

    const validateForm = useCallback(() => {
        const { errors: newErrors, isValid: isComponentValid } = validateComponentFields(componentLabel, componentName, componentNamesExist);
        let hasError = !isComponentValid;
        const newFieldErrors = validateComponentRowFields(fields);

        dispatch({ type: 'SET_ERRORS', payload: newErrors });
        dispatch({ type: 'SET_FIELD_ERRORS', payload: newFieldErrors });

        if (newFieldErrors.some(fieldErrorObj => {
            return Object.keys(fieldErrorObj).some(key => key !== 'id');
        })) {
            hasError = true;
        }

        return !hasError;
    }, [componentLabel, componentName, fields, componentNamesExist]);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setSubmitting(true);

        dispatch({ type: 'SET_FIELDS_INTERACTED', payload: true });
        dispatch({ type: 'SET_FIELD_INTERACTED', payload: formMarkFieldsInteracted(fields) });

        if (!validateForm()) {
            setSubmitting(false);
            return;
        }

        const componentData = {
            component_label: componentLabel.trim(),
            component_name: componentName.trim(),
            location,
            synced: false,
            sort_order: 0,
            fields: formAssignSortOrderFields(fields),
        };

        try {
            await dataPOST(componentData);
            window.location.href = `${adminLink}?page=recomb`;
        } catch(error) {
            console.error(`${__('Creating component failed:')}`, error);
            dispatch({ type: 'SET_ERROR_MESSAGE', payload: __('Something went wrong.', 'recomb') });
            setSubmitting(false);
        }
    };


    return (
        <Layout>
            <form id="recomb-form" className="recomb_form" onSubmit={handleSubmit}>
                <div className="recomb_component-create recomb_block">
                    <div className="recomb_block-header">
                        <div className="recomb_block-header-content">
                            <h2>{__('Create Component', 'recomb')}</h2>

                            <div className="recomb_field-row">
                                <InputField labelText="Component Label" name="component-label" value={componentLabel} 
                                            onChangeText={handleInputFields('componentLabel')} errors={errors.componentLabel} />
                                <InputField labelText="Component Name" name="component-name" value={componentName} 
                                            onChangeText={handleInputFields('componentName')} errors={errors.componentName} />
                            </div>
                        </div>

                        {state.isSubmitting ? (
                            <LoadingAnimation />
                        ) : (
                            <ButtonSubmit buttonText="Save" disabled={state.isSubmitting} />
                        )} 
                    </div>

                    {errorMessage && (
                        <div className="recomb_error-general" aria-live="polite">
                            <span>{errorMessage}</span>
                        </div>
                    )}

                    <TableFields dispatch={dispatch} fields={fields} setFields={updateFields} fieldErrors={fieldErrors}
                                setFieldErrors={(errs) => dispatch({ type: 'SET_FIELD_ERRORS', payload: errs })}
                                fieldsInteracted={fieldsInteracted} fieldInteracted={fieldInteracted} 
                                setFieldInteracted={(map) => dispatch({ type: 'SET_FIELD_INTERACTED', payload: map })} />
                </div>

                <div className="recomb_component-location recomb_block">
                    <div className="recomb_block-header">
                        <h2>{__('Location', 'recomb')}</h2>
                    </div>

                    <TableLocation location={location} setLocation={(loc) => dispatch({ type: 'SET_LOCATION', payload: loc })} />
                </div>
            </form>
        </Layout>
    );
}
