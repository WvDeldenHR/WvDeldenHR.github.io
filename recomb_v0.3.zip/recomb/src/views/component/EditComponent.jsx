import { useCallback, useEffect, useReducer, useState } from "react";
import { __ } from '@wordpress/i18n';
import { dataGETComponent, dataPUT } from "../../config/api";
import { componentDefaults, componentReducer } from "../../utility/state";
// import { formAssignSortOrderFields, validateComponent, validateComponentFields } from "../../utility/form";
import { adminLink } from "../../utility/utility";
// Components
import Layout from "../../components/layout/Layout";
import TableFields from "../../components/form/table/TableFields";
import InputField from "../../components/form/input/InputField";
import ButtonSubmit from "../../components/button/ButtonSubmit";
import LoadingAnimation from "../../components/animation/LoadingAnimation";


export default function EditComponent() {
    const [state, dispatch] = useReducer(componentReducer, componentDefaults);
    const { componentLabel, componentName, fields, errors, errorMessage, fieldErrors } = state
    const id = ReCombData.id;
    
    useEffect(() => {
        dataGETComponent(id)
            .then((fetchedComponent) => {
                 console.log("Fetched component:", fetchedComponent);
                dispatch({ type: 'SET_COMPONENT_LABEL', payload: fetchedComponent.component_label });
                dispatch({ type: 'SET_COMPONENT_NAME', payload: fetchedComponent.component_name });
                dispatch({ type: 'SET_FIELDS', payload: fetchedComponent.fields});
            })
            .catch((err) => {
                console.error("Failed to fetch component", err);
            });
    }, [id]);

    const setSubmitting = useCallback((isSubmitting) => {
        dispatch({ type: 'SET_SUBMITTING', payload: isSubmitting });
    }, []);

    const handleInputFields = useCallback((field) => (e) => {
        const value = e.target.value;
        if (field === 'componentLabel') {
            dispatch({ type: 'SET_COMPONENT_LABEL', payload: value });
        } else if (field === 'componentName') {
            dispatch({ type: 'SET_COMPONENT_NAME', payload: value });
        }
    }, []);

    const updateFields = useCallback((updatedFields) => {
        if (!Array.isArray(updatedFields)) return;
        dispatch({ type: 'SET_FIELDS', payload: updatedFields });
        dispatch({ type: 'SET_FIELD_ERRORS', payload: validateComponentFields(updatedFields) });
    }, []);

    const validateForm = useCallback(() => {
        const { errors: newErrors, isValid: isComponentValid } = validateComponent(componentLabel, componentName);
        let hasError = !isComponentValid;
        const newFieldErrors = validateComponentFields(fields);

        dispatch({ type: 'SET_ERRORS', payload: newErrors });
        dispatch({ type: 'SET_FIELD_ERRORS', payload: newFieldErrors });

        if (newFieldErrors.some(fieldErrorObj => {
            return Object.keys(fieldErrorObj).some(key => key !== 'id');})) {
            hasError = true;
        }

        return !hasError;
    }, [componentLabel, componentName]);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setSubmitting(true);

        if (!validateForm()) {
            setSubmitting(false);
            return;
        }

        const componentData = {
            component_label: componentLabel.trim(),
            component_name: componentName.trim(),
            fields: formAssignSortOrderFields(fields)
        }

        try {
            await dataPUT(id, componentData);
            window.location.href = `${adminLink}?page=recomb`;
        } catch(error) {
            console.error(`${__('Editting component failed:')}`, error);
            dispatch({ type: 'SET_ERROR_MESSAGE', payload: __('Something went wrong.', 'recomb') });
            setSubmitting(false);
        }
    };


    return (
        <Layout>
            <form id="recomb-form" className="recomb_form" onSubmit={handleSubmit}>
                <div className="recomb_component-edit recomb_block">
                    <div className="recomb_block-header">
                        <div className="recomb_block-header-content">
                            <h2>{__('Edit Component', 'recomb')}</h2>

                            <div className="recomb_field-row">
                                <InputField labelText="Component Label" name="component-label" value={componentLabel}
                                            onChangeText={handleInputFields('componentLabel')} errors={errors.componentLabel}/>
                                <InputField labelText="Component Name" name="component-name" value={componentName} 
                                            onChangeText={handleInputFields('componentName')} errors={errors.componentName}/>
                            </div>
                        </div>

                        {state.isSubmitting ? (
                            <LoadingAnimation />
                        ) : (
                            <ButtonSubmit buttonText="Save" disabled={state.isSubmitting} />
                        )}
                    </div>

                    {errorMessage && (
                        <div className="recomb_error-general" aria-live="polite">
                            <span>{errorMessage}</span>
                        </div>
                    )}

                    <TableFields dispatch={dispatch} fields={fields} setFields={updateFields}/>
                </div>

                <div className="recomb_component-location recomb_block">
                    <div className="recomb_block-header">
                        <h2>{__('Location Component', 'recomb')}</h2>
                    </div>
                </div>
            </form>
        </Layout>
    );
}
