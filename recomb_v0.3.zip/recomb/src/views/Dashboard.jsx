import { __ } from '@wordpress/i18n';
// Components
import Layout from '../components/layout/Layout';
import TableComponents from '../components/form/table/TableComponents';
import ButtonLink from '../components/button/ButtonLink';
import Synch from '../components/form/Synch';
import ExportComponent from '../components/form/ExportComponent';
import ImportComponent from '../components/form/ImportComponent';



export default function Dashboard() {
    return (
        <Layout>
            <div className="recomb_dashboard recomb_columns">
                <div className="recomb_column recomb_block">
                    <div className="recomb_block-header">
                        <h2>{__('Components', 'recomb')}</h2>

                        <ButtonLink buttonLink="_create_component" buttonText={__('Add Component', 'recomb')}/>
                    </div>

                    <TableComponents blockClass="recomb_column"/>
                </div>

                <div className="recomb_column recomb_block">
                    <h2>{__('Synchronization', 'recomb')}</h2>

                    <div className="recomb_block-content">
                        <h3>{__('Code', 'recomb')}</h3>

                        <div className="recomb_button-end">
                            <Synch />
                        </div>
                        
                    </div>

                    <div className="recomb_block-content">
                        <h3>{__('Files', 'recomb')}</h3>

                        <div className="recomb_button-row">
                            <ExportComponent />
                            <ImportComponent />
                        </div>
                    </div>
                </div>
            </div>
        </Layout>
    );
}
