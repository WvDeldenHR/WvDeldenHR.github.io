// Links
export const adminLink = window.ReCombData?.adminUrl ?? 'admin.php';
