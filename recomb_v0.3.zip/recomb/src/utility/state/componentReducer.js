// Reducer function for component
export function componentReducer(state, action) {
    switch(action.type) {
        case 'SET_COMPONENT_LABEL':
            return {
                ...state,
                componentLabel: action.payload,
                errors: { ...state.errors, componentLabel: undefined },
            };
        case 'SET_COMPONENT_NAME':
            return {
                ...state,
                componentName: action.payload,
                errors: { ...state.errors, componentName: undefined },
            };
        case 'SET_FIELDS':
            const fieldsArray = Array.isArray(action.payload) ? action.payload : [];
            return {
                ...state,
                fields: fieldsArray,
                fieldErrors: fieldsArray.map(() => ({})),
                fieldInteracted: fieldsArray.map(() => ({})),
            };
        case 'SET_LOCATION':
            return { ...state, location: action.payload };
        case 'SET_FIELD_INTERACTED':
            return { ...state, fieldInteracted: action.payload };
        case 'SET_FIELDS_INTERACTED':
            return { ...state, fieldsInteracted: action.payload };
        case 'SET_SUBMITTING':
            return { ...state, isSubmitting: action.payload };
        case 'SET_ERRORS':
            return { ...state, errors: action.payload };
        case 'SET_FIELD_ERRORS':
            return { ...state, fieldErrors: action.payload };
        case 'SET_ERROR_MESSAGE':
            return { ...state, errorMessage: action.payload };
        default:
            return state;
    }
}
