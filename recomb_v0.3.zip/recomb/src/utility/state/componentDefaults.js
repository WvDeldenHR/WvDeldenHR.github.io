import { GENERATED_ID } from "../../config/constants";

// Component field structure
export const initField = {
    id: GENERATED_ID(),
    field_label: '',
    field_name: '',
    field_type: 'text',
    field_child: [],
};

// Initial state object for a component
export const componentDefaults = {
    componentLabel: '',
    componentName: '',
    fields: [initField],
    location: '',
    fieldInteracted: [{}],
    fieldsInteracted: false,
    isSubmitting: false,
    errors: {},
    fieldErrors: [{}],
    errorMessage: '',
};
