import { useCallback, useRef, useEffect } from "react";


// Copy styling of dragged row
function copyComputedStyles(source, target) {
    const computedStyle = window.getComputedStyle(source);
    for (let i = 0; i < computedStyle.length; i++) {
        const prop = computedStyle[i];
        try {
            target.style.setProperty(prop, computedStyle.getPropertyValue(prop));
        } catch {}
    }

    const sourceChildren = source.children;
    const targetChildren = target.children;

    for (let i = 0; i < sourceChildren.length; i++) {
        if (targetChildren[i]) {
            copyComputedStyles(sourceChildren[i], targetChildren[i]);
        }
    }
}

//
function createStyledDragImage(sourceElement) {
    const clone = sourceElement.cloneNode(true);
    copyComputedStyles(sourceElement, clone);

    clone.classList.add("recomb_table-row-drag-image");
    Object.assign(clone.style, {
        position: "absolute",
        zIndex: "1000",
    });

    document.body.appendChild(clone);
    return clone;
}


export function useDraggable({
    items,
    setItems,
    currentlyDraggedId,
    setCurrentlyDraggedId,
    setDragging,
    itemRefs
}) {
    const hasReorderedRef = useRef(false);
    const originalItemsRef = useRef(null);
    const draggedItemRef = useRef(null);
    const latestItemsRef = useRef(items);
    const didDropRef = useRef(false);
    const dragOverItem = useRef({ id: null, position: null });
    const validDropRef = useRef({ root: false });
    
    useEffect(() => {
        latestItemsRef.current = items;
    }, [items]);

    const handleDragStart = useCallback((e, id) => {
        setDragging(true);
        draggedItemRef.current = id;
        originalItemsRef.current = structuredClone(items);
        setCurrentlyDraggedId(id);
        validDropRef.current = {};
        hasReorderedRef.current = false;

        const fullBlock = itemRefs.current[id];
        if (fullBlock) {
            const dragImage = createStyledDragImage(fullBlock);
            e.dataTransfer.setDragImage(dragImage, 0, 0);
            setTimeout(() => document.body.removeChild(dragImage), 0);
        }
    }, [items, setCurrentlyDraggedId, setDragging]);


    function handleDragOver(e) {
        e.preventDefault();

        const firstItemEl = itemRefs.current[items[0]?.id];
        const lastItemEl = itemRefs.current[items[items.length - 1]?.id];

        if (!firstItemEl || !lastItemEl) {
            validDropRef.current = false;
            return;
        }

        const mouseY = e.clientY;
        const firstTop = firstItemEl.getBoundingClientRect().top;
        const lastBottom = lastItemEl.getBoundingClientRect().bottom;

        if (mouseY < firstTop || mouseY > lastBottom) {
            validDropRef.current = false;
            return;
        }

        validDropRef.current = true;
    }

    const onDragOverItem = useCallback((e, targetId) => {
        e.preventDefault();
        if (!validDropRef.current) return;

        const draggedId = currentlyDraggedId;
        if (!draggedId || draggedId === targetId) return;

        const targetEl = itemRefs.current[targetId];
        if (!targetEl) return;

        const rect = targetEl.getBoundingClientRect();
        const mouseY = e.clientY;
        const position = mouseY > rect.top + rect.height / 2 ? "below" : "above";

        const dragOver = dragOverItem.current;
        if (dragOver.id === targetId && dragOver.position === position && hasReorderedRef.current) return;

        dragOverItem.current = { id: targetId, position };
        const currentItems = latestItemsRef.current;

        function findParentAndIndex(list, id, parent = null) {
            for (let i = 0; i < list.length; i++) {
                if (list[i].id === id) return { parent, index: i };
                if (list[i].field_child) {
                    const res = findParentAndIndex(list[i].field_child, id, list[i]);
                    if (res) return res;
                }
            }
            return null;
        }

        function isDescendant(parent, id) {
            if (!parent.field_child) return false;
            for (const child of parent.field_child) {
                if (child.id === id || isDescendant(child, id)) return true;
            }
            return false;
        }

        function findAndRemove(rows, id) {
            let removedItem = null;
            const filtered = [];

            for (const item of rows) {
                if (item.id === id) {
                    removedItem = item;
                    continue;
                }
                if (item.field_child) {
                    const [newChildren, found] = findAndRemove(item.field_child, id);
                    if (found) {
                        removedItem = found;
                        filtered.push({ ...item, field_child: newChildren });
                        continue;
                    }
                }
                filtered.push(item);
            }
            return [filtered, removedItem];
        }

        function insertAtPosition(rows, targetId, itemToInsert, position) {
            let inserted = false;

            function recursiveInsert(items) {
                const result = [];
                for (const item of items) {
                    if (inserted) {
                        result.push(item);
                        continue;
                    }

                    if (item.id === targetId) {
                        inserted = true;
                        if (position === "above") {
                            result.push(itemToInsert, item);
                        } else if (position === "below") {
                            result.push(item, itemToInsert);
                        } else if (position === "inside") {
                            result.push({
                                ...item,
                                field_child: [...(item.field_child ?? []), itemToInsert],
                            });
                        }
                    } else if (item.field_child) {
                        result.push({
                            ...item,
                            field_child: recursiveInsert(item.field_child),
                        });
                    } else {
                        result.push(item);
                    }
                }
                return result;
            }

            const newRows = recursiveInsert(rows);

            if (!inserted) {
                console.warn("insertAtPosition: No valid target found, skipping insertion");
                return rows;
            }
            return newRows;
        }

        const draggedPos = findParentAndIndex(currentItems, draggedId);
        const targetPos = findParentAndIndex(currentItems, targetId);

        if (!draggedPos || !targetPos) return;

        if (
            (position === "inside" && draggedPos.parent?.id === targetId) ||
            (
                draggedPos.parent?.id === targetPos.parent?.id &&
                (
                    (position === "above" && draggedPos.index === targetPos.index - 1) ||
                    (position === "below" && draggedPos.index === targetPos.index + 1)
                )
            )
        ) return;

        const [withoutDragged, draggedItem] = findAndRemove(currentItems, draggedId);
        if (!draggedItem) return;

        if (targetId && isDescendant(draggedItem, targetId)) return;

        const updated = insertAtPosition(withoutDragged, targetId, draggedItem, position);

        validDropRef.current = { root: true };
        hasReorderedRef.current = true;

        if (JSON.stringify(updated) === JSON.stringify(currentItems)) {
            console.warn("🚨 Attempted reorder, but updated list is structurally identical — skipping.");
            return;
        }

        setItems(updated);
    }, [currentlyDraggedId, setItems]);


    function handleItemDrop(e) {
        e.preventDefault();
        didDropRef.current = true;
        handleDrop();
    }

    function handleItemDragEnd() {
        if (!didDropRef.current) {
            handleDrop();
        }
        didDropRef.current = false;
    }

    const handleDrop = useCallback(() => {
        const draggedId = currentlyDraggedId;
        if (!draggedId) return;

        const isValidDrop = validDropRef.current;

        if (!isValidDrop || !hasReorderedRef.current) {
            if (originalItemsRef.current) {
                setItems(originalItemsRef.current);
            }
        }

        setDragging(false);
        setCurrentlyDraggedId(null);
        dragOverItem.current = { id: null, position: null };
        hasReorderedRef.current = false;
        originalItemsRef.current = null;
        draggedItemRef.current = null;
        validDropRef.current = {};
    }, [currentlyDraggedId, setDragging, setCurrentlyDraggedId, setItems, dragOverItem, validDropRef]);

    const handleDragLeave = useCallback(() => {
        validDropRef.current = false;
    }, []);

    return {
        onDragOverItem,
        handleDragOver,
        handleDrop,
        handleDragStart,
        handleItemDragEnd,
        handleItemDrop,
        handleDragLeave
    };
}