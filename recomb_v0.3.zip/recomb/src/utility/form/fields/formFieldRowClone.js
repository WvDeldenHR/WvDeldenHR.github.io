import { __ } from '@wordpress/i18n';
import { GENERATED_ID } from "../../../config/constants";


export function formFieldRowClone({ dispatch, fields, setFields }, id) {
    if (!Array.isArray(fields)) {
        console.warn(__('Cloning row failed: Field row is not an array.', 'recomb'));
        dispatch?.({ type: 'SET_ERROR_MESSAGE', payload: __('Something went wrong.', 'recomb') });
        return;
    }

    if (typeof id !== 'string' && typeof id !== 'number') {
        console.warn(__('Cloning row failed: Invalid ID provided.', 'recomb'));
        dispatch?.({ type: 'SET_ERROR_MESSAGE', payload: __('Something went wrong.', 'recomb') });
        return;
    }

    const cloneRecursiveRow = (item) => ({
        ...item,
        id: GENERATED_ID(),
        field_child: Array.isArray(item.field_child)
            ? item.field_child.map(cloneRecursiveRow)
            : [],
    });

    const cloneRow = (rows) => {
        let result = [];

        for (const item of rows) {
        const children = Array.isArray(item.field_child)
            ? cloneRow(item.field_child)
            : [];

            if (item.id === id) {
                const clonedItem = cloneRecursiveRow(item);
                result.push({ ...item, field_child: children }, clonedItem);
            } else {
                result.push({ ...item, field_child: children });
            }
        }

        return result;
    };

    try {
        const updatedItems = cloneRow(fields);
        setFields(updatedItems);
    } catch(error) {
        console.error(`${__('Cloning row failed:')}`, error);
        dispatch?.({ type: 'SET_ERROR_MESSAGE', payload: __('Something went wrong.', 'recomb') });
    }
}
