import { __ } from '@wordpress/i18n';


export function formFieldRowDelete({ dispatch, fields, setFields }, id) {
    if (!Array.isArray(fields)) {
        console.warn(__('Deleting row failed: Field row is not an array.', 'recomb'));
        dispatch?.({ type: 'SET_ERROR_MESSAGE', payload: __('Something went wrong', 'recomb') });
        return;
    }

    if (typeof id !== 'string' && typeof id !== 'number') {
        console.warn(__('Deleting row failed: Invalid ID provided.', 'recomb'));
        dispatch?.({ type: 'SET_ERROR_MESSAGE', payload: __('Something went wrong', 'recomb') });
        return;
    }

    const deleteRow = (rows) =>
        rows.map((item) => ({
                ...item,
                field_child: item.field_child?.length ? deleteRow(item.field_child) : [],
            }))
            .filter((item) => item.id !== id);

    try {
        const updatedItems = deleteRow(fields);
        setFields(updatedItems);
    } catch(error) {
        console.error(`${__('Deleting row failed:')}`, error);
        dispatch?.({ type: 'SET_ERROR_MESSAGE', payload: __('Something went wrong.', 'recomb') });
    }
}
