import { __ } from '@wordpress/i18n';
import { GENERATED_ID } from "../../../config/constants";
import { initField } from "../../state";


export function formFieldRowAdd({ dispatch, fields, setFields }, field_parent_id = null) {
    if (!Array.isArray(fields)){
        console.warn(__('Adding row failed: Field row is not an array.', 'recomb'));
        dispatch?.({ type: 'SET_ERROR_MESSAGE', payload: __('Something went wrong', 'recomb') });
        return;
    }

    const newItem = { ...initField, id: GENERATED_ID(), field_child: [] };

    if (!field_parent_id) {
        const updatedItems = [...fields, newItem];
        setFields(updatedItems);
        return;
    }

    let hasParent = false;

    const insertChild = (rows) =>
        rows.map(item => {
            if (item.id === field_parent_id) {
                hasParent = true;
                return { ...item, field_child: [...(item.field_child || []), newItem] };
            }
                if (item.field_child?.length) {
                return { ...item, field_child: insertChild(item.field_child) };
            }
            return item;
        });

    const updatedItems = insertChild(fields);

    if (!hasParent) {
        console.warn(__('Adding row failed: Invalid or missing parent.', 'recomb'));
        dispatch?.({ type: 'SET_ERROR_MESSAGE', payload: __('Something went wrong', 'recomb') });
        return;
    }

    try {
        setFields(updatedItems);
    } catch(error) {
        console.error(`${__('Adding row failed:')}`, error);
        dispatch?.({ type: 'SET_ERROR_MESSAGE', payload: __('Something went wrong.', 'recomb') });
    }
}
