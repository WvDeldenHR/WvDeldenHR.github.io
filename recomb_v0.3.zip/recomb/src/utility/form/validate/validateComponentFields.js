import { __ } from '@wordpress/i18n';
import { formFieldValueExists, isNotEmptyField, normalizeString } from '../form';
import { MAX_LENGTH, VALID_FIELD_TEXT, VALID_FIELD_TEXT_BASIC } from '../../../config/constants';


// Component label and name validation
export function validateComponentFields(label, name, nameExists = []) {
    const errors = {};

    const normalizedLabel = normalizeString(label);
    const normalizedName = normalizeString(name);

    if (!isNotEmptyField(normalizedLabel)) {
        errors.componentLabel = __("Component label can't be empty", 'recomb');
    } else if (!VALID_FIELD_TEXT_BASIC(normalizedLabel)) {
        errors.componentLabel = __("Component label contains invalid characters", 'recomb');
    } else if (normalizedLabel.length > MAX_LENGTH) {
        errors.componentLabel = __("Component label is too long", 'recomb');
    }

    if (!isNotEmptyField(normalizedName)) {
        errors.componentName = __("Component name can't be empty", 'recomb');
    } else if (!VALID_FIELD_TEXT(normalizedName)) {
        errors.componentName = __("Invalid component name, must start with a letter or underscore", 'recomb');
    } else if (normalizedName.length > MAX_LENGTH) {
        errors.componentName = __("Component name is too long", 'recomb');
    } else if (formFieldValueExists(normalizedName, nameExists)) {
        errors.componentName = __("A component with this name already exists", 'recomb');
    }

    return {
        errors,
        isValid: Object.keys(errors).length === 0,
    };
}
