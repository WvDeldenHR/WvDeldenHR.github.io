import { __ } from '@wordpress/i18n';
import { isNotEmptyField, normalizeString } from '../form';
import { MAX_LENGTH, VALID_FIELD_TEXT, VALID_FIELD_TEXT_BASIC, VALID_FIELD_TYPES } from '../../../config/constants';


// Component field validation
export function validateComponentRowFields(fields = []) {
    if (!Array.isArray(fields)) return [];

    return fields.map((field = {}) => {
        const errors = { id: field.id || null };

        const label = normalizeString(field.field_label);
        const name = normalizeString(field.field_name);
        const type = field.field_type;

        // Label
        if (!isNotEmptyField(label)) {
            errors.field_label = __("Field label can't be empty", 'recomb');
        } else if (!VALID_FIELD_TEXT_BASIC(label)) {
            errors.field_label = __("Field label contains invalid characters", 'recomb');
        } else if (label.length > MAX_LENGTH) {
            errors.field_label = __("Field label is too long", 'recomb');
        }

        // Name
        if (!isNotEmptyField(name)) {
            errors.field_name = __("Field name can't be empty", 'recomb');
        } else if (!VALID_FIELD_TEXT(name)) {
            errors.field_name = __("Invalid field name, must start with a letter or underscore", 'recomb');
        } else if (name.length > MAX_LENGTH) {
            errors.field_name = __("Field name is too long", 'recomb');
        }

        // Type
        if (!VALID_FIELD_TYPES.includes(type)) {
            errors.field_type = __("Invalid field type", 'recomb');
        }

        // Children
        // if (type === 'component' && Array.isArray(field.field_child)) {
        //     errors.field_child = validateComponentFields(field.field_child);
        // }

        if (type === 'component' && Array.isArray(field.field_child)) {
            const childErrs = validateComponentRowFields(field.field_child);

            // Only attach `field_child` if there are *real* errors in them
            const hasRealChildErrors = childErrs.some(childErr =>
                Object.keys(childErr).some(key => key !== 'id')
            );

            if (hasRealChildErrors) {
                errors.field_child = childErrs;
            }
        }

        return errors;
    });
}
