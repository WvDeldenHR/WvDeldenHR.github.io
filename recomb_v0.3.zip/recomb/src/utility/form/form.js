/* ---- Field checks ---- */
// Check if field is not empty
export const isNotEmptyField = (value) => typeof value === 'string' && value.trim().length > 0;
// Trim string
export const normalizeString = (value) => typeof value === 'string' ? value.trim() : '';
// Field value exists
export function formFieldValueExists(fieldValue, fieldValueExists) {
    const normalizedFieldValue = fieldValue.trim().toLowerCase();
    return fieldValueExists.some(value => value.trim().toLowerCase() === normalizedFieldValue);
}

// Mark fields as interacted
export function formMarkFieldsInteracted(fields = []) {
    return Array.isArray(fields) ? fields.map(field => ({
        field_label: true,
        field_name: true,
        field_child: formMarkFieldsInteracted(field.field_child || []),
    })) : [];
}

// Assign sort order recursively to children
export function formAssignSortOrderFields(fields = []) {
    if (!Array.isArray(fields)) return [];
    return fields.map(({ field_label, field_name, field_type, field_child = [] }, index) => ({
        field_label,
        field_name,
        field_type,
        sort_order: index,
        field_child: formAssignSortOrderFields(field_child),
    }));
}
