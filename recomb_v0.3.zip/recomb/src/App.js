import React from 'react';
// Assets
import './assets/styles/main.scss';
// Views
import Dashboard from './views/Dashboard';
import ComponentCreate from './views/component/CreateComponent';
import EditComponent from './views/component/EditComponent';
import Settings from './views/Settings';


export default function App({ page }) {
    switch (page) {
        case 'recomb':
            return <Dashboard />;
        case 'recomb_create_component':
            return <ComponentCreate />;
        case 'recomb_edit_component':
            return <EditComponent />;
        case 'recomb_settings':
            return <Settings />;
        default:
            return <div>Unknown page: {page}</div>;
    }
}
