import domReady from '@wordpress/dom-ready';
import { createRoot } from '@wordpress/element';

import App from './App';
import Metabox from './components/metabox/Metabox';


domReady(() => {

    // Admin Plugin
    const container = document.getElementById('root');
    if (container) {
        const root = createRoot(container);
        const page = container.dataset.page || 'recomb';
        root.render(<App page={page} />);
    }

    // Admin Page / Post
    const metaboxes = document.querySelectorAll('.recomb-metabox');
    metaboxes.forEach((el) => {
        const meta = JSON.parse(el.dataset.meta || '{}');
        const root = createRoot(el);
        root.render(<Metabox id={meta.id} label={meta.component_label} />);
    });
});
