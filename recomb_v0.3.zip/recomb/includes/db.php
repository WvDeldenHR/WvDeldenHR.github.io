<?php

// Database Table Setup
function recomb_create_database_tables() {
    global $wpdb;

    $charset_collate = $wpdb->get_charset_collate();

    $table_components = $wpdb->prefix . 'recomb_components';
    $table_fields     = $wpdb->prefix . 'recomb_fields';
    $table_metabox       = $wpdb->prefix . 'recomb_metabox';

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';


    // Components Table
    $sql_components = "CREATE TABLE $table_components (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        sync_id VARCHAR(36) NOT NULL,
        component_label VARCHAR(255) NOT NULL,
        component_name VARCHAR(255) NOT NULL,
        location TEXT DEFAULT NULL,
        template_code LONGTEXT DEFAULT NULL,
        synced TINYINT(1) DEFAULT 0,
        sort_order INT DEFAULT 0,
        date_created DATETIME DEFAULT CURRENT_TIMESTAMP,
        date_updated DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY  (id),
        UNIQUE KEY sync_id (sync_id)
    ) $charset_collate;";


    // Fields Table
    $sql_fields = "CREATE TABLE $table_fields (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        component_id BIGINT UNSIGNED NOT NULL,
        field_label VARCHAR(255) NOT NULL,
        field_name VARCHAR(255) NOT NULL,
        field_type VARCHAR(100) NOT NULL,
        field_parent_id BIGINT UNSIGNED DEFAULT NULL,
        sort_order INT DEFAULT 0,
        date_created DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id),
        KEY component_id (component_id),
        FOREIGN KEY (component_id) REFERENCES $table_components(id) ON DELETE CASCADE,
        FOREIGN KEY (field_parent_id) REFERENCES $table_fields(id) ON DELETE CASCADE
    ) $charset_collate;";

    // Metabox Table
    $sql_metabox = "CREATE TABLE $table_metabox (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        post_id BIGINT UNSIGNED NOT NULL,
        component_id BIGINT UNSIGNED NOT NULL,
        field_id BIGINT UNSIGNED NOT NULL,
        parent_id BIGINT UNSIGNED DEFAULT NULL,
        group_index INT DEFAULT 0,
        order_in_group INT DEFAULT 0,
        value LONGTEXT DEFAULT NULL,
        date_created DATETIME DEFAULT CURRENT_TIMESTAMP,
        date_updated DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY post_component (post_id, component_id),
        FOREIGN KEY (component_id) REFERENCES $table_components(id) ON DELETE CASCADE,
        FOREIGN KEY (field_id) REFERENCES $table_fields(id) ON DELETE CASCADE,
        FOREIGN KEY (parent_id) REFERENCES $table_metabox(id) ON DELETE CASCADE
    ) $charset_collate;";

    dbDelta($sql_components);
    dbDelta($sql_fields);
    dbDelta($sql_metabox);
}
