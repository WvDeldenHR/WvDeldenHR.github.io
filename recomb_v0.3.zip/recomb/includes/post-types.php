<?php

// Fetch Post Types (CPT's + post + page)
function recomb_get_filtered_post_types() {
    $types = get_post_types(['public' => true], 'objects');

    $allowed_builtin = ['post', 'page'];

    $post_types = array_filter($types, function($type) use ($allowed_builtin) {
        return !$type->_builtin || in_array($type->name, $allowed_builtin);
    });

    return array_values(array_map(function($type) {
        return [
            'slug'  => $type->name,
            'label' => $type->labels->singular_name,
        ];
    }, $post_types));
}
