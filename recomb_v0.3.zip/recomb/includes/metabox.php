<?php

// Add metaboxes for all components
add_action('add_meta_boxes', 'recomb_add_metaboxes');
function recomb_add_metaboxes() {
    global $wpdb;
    $table = $wpdb->prefix . 'recomb_components';
    $components = $wpdb->get_results("SELECT id, component_label FROM $table", ARRAY_A);

    foreach ($components as $component) {
        add_meta_box(
            'recomb_component_' . $component['id'],
            esc_html($component['component_label']),
            'recomb_render_metabox',
            ['post', 'page'],
            'normal',
            'default',
            $component
        );
    }
}

// Metabox render callback, receives component via $args
function recomb_render_metabox($post, $args) {
    $component = $args['args'];

    // Ensure $saved is always a string
    $saved_raw = get_post_meta($post->ID, '_recomb_component_' . $component['id'], true);
    $saved = is_string($saved_raw) ? $saved_raw : json_encode($saved_raw);

    echo '<div class="recomb-metabox" '
        . 'data-meta="' . esc_attr(json_encode($component)) . '" '
        . 'data-value="' . esc_attr($saved) . '">'
        . '</div>';
}


add_action('rest_api_init', function () {
    register_rest_route('recomb/v1', '/metabox-data', [
        'methods' => 'GET',
        'callback' => 'recomb_get_metabox_data',
        'permission_callback' => function () {
            return current_user_can('manage_options');
        },
        'args' => [
            'post_id' => [
                'required' => true,
                'validate_callback' => function($param) {
                    return is_numeric($param);
                }
            ],
            'component_id' => [
                'required' => true,
                'validate_callback' => function($param) {
                    return is_numeric($param);
                }
            ],
        ],
    ]);

    register_rest_route('recomb/v1', '/metabox-data', [
        'methods' => 'POST',
        'callback' => 'handle_save_metabox_data',
        'permission_callback' => function () {
            return current_user_can('manage_options');
        },
        'args' => [
            'field1' => [
                'required' => true,
                'validate_callback' => function($param) {
                    return is_string($param);
                }
            ],
        ],
    ]);
});

function recomb_get_metabox_data(WP_REST_Request $request) {
    global $wpdb;

    $post_id = intval($request->get_param('post_id'));
    $component_id = intval($request->get_param('component_id'));
    $table_metabox = $wpdb->prefix . 'recomb_metabox';

    $results = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT * FROM $table_metabox WHERE post_id = %d AND component_id = %d ORDER BY group_index, order_in_group",
            $post_id,
            $component_id
        ),
        ARRAY_A
    );

    return rest_ensure_response($results);
}

function handle_save_metabox_data(WP_REST_Request $request) {
    global $wpdb;

    $params = $request->get_params();

    $post_id = isset($params['post_id']) ? intval($params['post_id']) : 0;
    $component_id = isset($params['component_id']) ? intval($params['component_id']) : 0;
    $field_id = isset($params['field_id']) ? intval($params['field_id']) : 0;
    $parent_id = isset($params['parent_id']) ? intval($params['parent_id']) : null;
    $group_index = isset($params['group_index']) ? intval($params['group_index']) : 0;
    $order_in_group = isset($params['order_in_group']) ? intval($params['order_in_group']) : 0;
    $value = isset($params['value']) ? sanitize_text_field($params['value']) : '';

    if (!$post_id || !$component_id || !$field_id) {
        return new WP_Error('invalid_data', 'Missing required IDs', ['status' => 400]);
    }

    $table_metabox = $wpdb->prefix . 'recomb_metabox';

    $existing_id = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT id FROM $table_metabox WHERE post_id = %d AND component_id = %d AND field_id = %d AND group_index = %d AND order_in_group = %d",
            $post_id, $component_id, $field_id, $group_index, $order_in_group
        )
    );

    $data = [
        'post_id' => $post_id,
        'component_id' => $component_id,
        'field_id' => $field_id,
        'parent_id' => $parent_id,
        'group_index' => $group_index,
        'order_in_group' => $order_in_group,
        'value' => $value,
    ];
    $formats = ['%d', '%d', '%d', '%d', '%d', '%d', '%s'];

    $inserted = $wpdb->insert($table_metabox, $data, $formats);
    if (!$inserted) {
        error_log('Insert failed: ' . $wpdb->last_error);
    }

    if ($existing_id) {
        $updated = $wpdb->update($table_metabox, $data, ['id' => $existing_id]);
        if ($updated === false) {
            return new WP_Error('db_error', 'Failed to update data', ['status' => 500]);
        }
    } else {
        $inserted = $wpdb->insert($table_metabox, $data);
        if (!$inserted) {
            return new WP_Error('db_error', 'Failed to insert data', ['status' => 500]);
        }
    }

    if ($wpdb->last_error) {
        error_log('DB error: ' . $wpdb->last_error);
    }

    error_log('Received params: ' . print_r($params, true));

    return [
        'success' => true,
        'message' => 'Data saved successfully',
    ];
}
add_action('save_post', 'recomb_save_metabox_data', 10, 2);


function recomb_save_metabox_data($post_id, $post) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_post', $post_id)) return;
    if (empty($_POST['recomb_metabox_data']) || !is_array($_POST['recomb_metabox_data'])) return;

    global $wpdb;
    $table = $wpdb->prefix . 'recomb_metabox';

    // Recursive save function to save parents before children
    function save_entries_recursively($entries, $parent_temp_id = null, &$uuid_to_id_map, $post_id, $component_id, $wpdb, $table) {
    // function save_entries_recursively($entries, &$uuid_to_id_map, $post_id, $component_id, $wpdb, $table, $parent_temp_id = null) {
        foreach ($entries as $entry) {
            // Use null for no parent, string otherwise (don't cast to int!)
            $entry_parent_temp_id = isset($entry['parent_temp_id']) ? $entry['parent_temp_id'] : null;
            if ($entry_parent_temp_id === $parent_temp_id) {
                $temp_id = $entry['temp_id']; // string or numeric, do NOT cast
                $field_id = intval($entry['field_id']);
                $value = sanitize_text_field($entry['value']);
                $group_index = intval($entry['group_index'] ?? 0);
                $order_in_group = intval($entry['order_in_group'] ?? 0);

                // Resolve parent_id from map
                $parent_id = ($parent_temp_id !== null && isset($uuid_to_id_map[$parent_temp_id])) ? $uuid_to_id_map[$parent_temp_id] : null;

                $data = [
                    'post_id' => $post_id,
                    'component_id' => intval($component_id),
                    'field_id' => $field_id,
                    'value' => $value,
                    'group_index' => $group_index,
                    'order_in_group' => $order_in_group,
                ];
                $formats = ['%d', '%d', '%d', '%s', '%d', '%d'];

                if ($parent_id !== null) {
                    $data['parent_id'] = $parent_id;
                    $formats[] = '%d';
                }

                // Check if existing DB row: temp_id could be UUID or DB id
                // If temp_id is numeric string, try to find existing row by that id
                $existing_id = (is_numeric($temp_id) && $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table WHERE id = %d", intval($temp_id)))) 
                               ? intval($temp_id) 
                               : null;

                if ($existing_id) {
                    // Update existing row
                    $wpdb->update($table, $data, ['id' => $existing_id], $formats);
                    $uuid_to_id_map[$temp_id] = $existing_id;
                } else {
                    // Insert new row
                    $wpdb->insert($table, $data, $formats);
                    $insert_id = $wpdb->insert_id;
                    $uuid_to_id_map[$temp_id] = $insert_id;
                }

                // Recurse to save children of this entry
                save_entries_recursively($entries, $temp_id, $uuid_to_id_map, $post_id, $component_id, $wpdb, $table);
            }
        }
    }

    foreach ($_POST['recomb_metabox_data'] as $component_id => $json_raw) {
        $json = stripslashes_deep($json_raw);
        $entries = json_decode($json, true);
        if (!is_array($entries)) continue;

        $uuid_to_id_map = [];

        // Save all entries recursively, parents first
        save_entries_recursively($entries, null, $uuid_to_id_map, $post_id, $component_id, $wpdb, $table);
    }
}

