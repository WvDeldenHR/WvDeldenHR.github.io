<?php

// REST API
add_action('rest_api_init', function () {
    // GET Components
    register_rest_route('recomb/v1', '/components', [
        'methods'  => 'GET',
        'callback' => 'recomb_get_components',
        'permission_callback' => function () {
            return current_user_can('manage_options');
        },
    ]);

    // GET Component
    register_rest_route('recomb/v1', '/components/(?P<id>\d+)', [
        'methods'  => 'GET',
        'callback' => 'recomb_get_component_by_id',
        'permission_callback' => function () {
            return current_user_can('manage_options');
        },
    ]);

    // GET Metabox
  


    // POST Component
    register_rest_route('recomb/v1', '/components', [
        'methods'  => 'POST',
        'callback' => 'recomb_create_component',
        'permission_callback' => function () {
            return current_user_can('manage_options');
        },
        'args' => [
            'component_label' => ['required' => true, 'type' => 'string'],
            'component_name' => ['required' => true, 'type' => 'string'],
            'fields' => ['required' => false, 'type' => 'array'],
            'location' => ['required' => false, 'type' => 'string'],
            'synced' => ['required' => false, 'type' => 'boolean'],
            'sort_order' => ['required' => false, 'type' => 'integer'],
        ],
    ]);

    // UPDATE Component
    register_rest_route('recomb/v1', '/components/(?P<id>\d+)', [
        'methods'  => 'POST', // or 'PUT'
        'callback' => 'recomb_update_component',
        'permission_callback' => function () {
            return current_user_can('manage_options');
        },
        'args' => [
            'id' => ['required' => true, 'type' => 'integer'],
            'component_label' => ['required' => false, 'type' => 'string'],
            'component_name' => ['required' => false, 'type' => 'string'],
            'location' => ['required' => false, 'type' => 'string'],
            'synced' => ['required' => false, 'type' => 'boolean'],
            'sort_order' => ['required' => false, 'type' => 'integer'],
            'template_code' => ['required' => false, 'type' => 'string'],
        ],
    ]);

    // DELETE Component
    register_rest_route('recomb/v1', '/components/(?P<id>\d+)', [
        'methods'  => 'DELETE',
        'callback' => 'recomb_delete_component',
        'permission_callback' => function () {
            return current_user_can('manage_options');
        },
        'args' => [
            'id' => [
                'required' => true,
                'type' => 'integer',
            ],
        ],
    ]);
});


// READ / GET
function recomb_get_components($request) {
    global $wpdb;

    $table_components = $wpdb->prefix . 'recomb_components';
    $table_fields     = $wpdb->prefix . 'recomb_fields';


    $components = $wpdb->get_results("SELECT * FROM $table_components ORDER BY sort_order ASC", ARRAY_A);

    foreach ($components as &$component) {
        $component_id = (int) $component['id'];

        $field_count = $wpdb->get_var(
            $wpdb->prepare("SELECT COUNT(*) FROM $table_fields WHERE component_id = %d", $component_id)
        );

        $component['field_count'] = (int) $field_count;
    }

    return rest_ensure_response($components);
}

function recomb_get_component_by_id(WP_REST_Request $request) {
    global $wpdb;

    $id = $request->get_param('id');

    $components_table = $wpdb->prefix . 'recomb_components';
    $fields_table = $wpdb->prefix . 'recomb_fields';

    $component = $wpdb->get_row($wpdb->prepare("SELECT * FROM $components_table WHERE id = %d", $id), ARRAY_A);

    if (!$component) {
        return new WP_Error('not_found', 'Component not found', ['status' => 404]);
    }

    $fields = $wpdb->get_results(
        $wpdb->prepare("SELECT * FROM $fields_table WHERE component_id = %d ORDER BY sort_order ASC", $id),
        ARRAY_A
    );

    $component['fields'] = $fields;

    return $component;
}


// CREATE / POST
function recomb_create_component($request) {
    global $wpdb;

    $table_components = $wpdb->prefix . 'recomb_components';
    $table_fields     = $wpdb->prefix . 'recomb_fields';

    $component_label    = sanitize_text_field($request['component_label']);
    $component_name     = sanitize_text_field($request['component_name']);
    $sync_id            = wp_generate_uuid4();
    $fields             = $request['fields'];
    $location           = sanitize_textarea_field($request['location']);
    $template_code      = $request['template_code'];
    $synced             = isset($request['synced']) ? (int)$request['synced'] : 0;
    $sort_order         = isset($request['sort_order']) ? (int)$request['sort_order'] : 0;
    $current_time       = current_time('mysql');


    // Check for existing component_name
    $existing = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT COUNT(*) FROM $table_components WHERE component_name = %s",
            $component_name
        )
    );

    if ( $existing > 0 ) {
        return new WP_Error('component_name_exists', __('Component name already exists.', 'recomb'), ['status' => 400]);
    }

    // Insert Component
    $inserted = $wpdb->insert($table_components, [
        'sync_id'           => $sync_id,
        'component_label'   => $component_label,
        'component_name'    => $component_name,
        'location'          => $location,
        'template_code'     => $template_code,
        'synced'            => $synced,
        'sort_order'        => $sort_order,
        'date_created'      => $current_time,
        'date_updated'      => $current_time,
    ]);

    if (!$inserted) {
        return new WP_Error('insert_failed', 'Failed to insert component', ['status' => 500]);
    }

    $component_id = $wpdb->insert_id;

    // Insert fields (recursive for nested fields)
    if (!empty($fields) && is_array($fields)) {
        insert_component_fields_recursive($fields, $component_id, null);
    }

    return rest_ensure_response(['success' => true, 'component_id' => $component_id]);
}

function insert_component_fields_recursive($fields, $component_id, $parent_id = null) {
    global $wpdb;
    $table_fields = $wpdb->prefix . 'recomb_fields';

    foreach ($fields as $field) {
        $field_name  = sanitize_text_field($field['field_name']);
        $field_label = sanitize_text_field($field['field_label']);
        $field_type  = sanitize_text_field($field['field_type']);
        $sort_order  = isset($field['sort_order']) ? (int)$field['sort_order'] : 0;

        // Insert the field
        $wpdb->insert($table_fields, [
            'component_id'   => $component_id,
            'field_name'     => $field_name,
            'field_label'    => $field_label,
            'field_type'     => $field_type,
            'field_parent_id'=> $parent_id,
            'sort_order'     => $sort_order,
            'date_created'   => current_time('mysql'),
        ]);

        $field_id = $wpdb->insert_id;

        // If the field has child fields (nested)
        if (!empty($field['field_child']) && is_array($field['field_child'])) {
            insert_component_fields_recursive($field['field_child'], $component_id, $field_id);
        }
    }
}


// UPDATE / EDIT
function recomb_update_component($request) {
    global $wpdb;

    $id = (int) $request['id'];
    $table_components = $wpdb->prefix . 'recomb_components';

    $data = [];
    $fields_to_check = ['component_label', 'component_name', 'location', 'synced', 'sort_order', 'template_code'];

    foreach ($fields_to_check as $field) {
        if (!is_null($request[$field])) {
            $data[$field] = sanitize_text_field($request[$field]);
        }
    }

    if (empty($data)) {
        return new WP_Error('no_data', 'No fields provided to update', ['status' => 400]);
    }

    $data['date_updated'] = current_time('mysql');

    $updated = $wpdb->update($table_components, $data, ['id' => $id]);

    if ($updated === false) {
        return new WP_Error('update_failed', 'Failed to update component', ['status' => 500]);
    }

    return rest_ensure_response(['success' => true, 'updated' => $id]);
}


// DELETE
function recomb_delete_component($request) {
    global $wpdb;

    $component_id = (int) $request['id'];
    $table_components = $wpdb->prefix . 'recomb_components';

    $deleted = $wpdb->delete($table_components, ['id' => $component_id], ['%d']);

    if ($deleted === false) {
        return new WP_Error('delete_failed', 'Failed to delete component', ['status' => 500]);
    }

    return rest_ensure_response(['success' => true, 'deleted' => $component_id]);
}
