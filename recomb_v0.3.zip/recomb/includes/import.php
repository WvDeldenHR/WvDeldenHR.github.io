<?php
function recomb_import_component( WP_REST_Request $request ) {
    global $wpdb;
    $component = $request->get_json_params();

    if ( isset($component['id']) ) {
        unset($component['id']); // remove old id
    }

    // Generate a new sync_id if needed
    $component['sync_id'] = wp_generate_uuid4();

    $fields = $component['fields'] ?? [];
    unset($component['fields']); // remove fields from component before insert

    // Insert component
    $table = $wpdb->prefix . 'recomb_components';
    $inserted = $wpdb->insert($table, $component);

    if ( !$inserted ) {
        return new WP_Error('db_error', 'Failed to insert component', ['status' => 500]);
    }

    $new_component_id = $wpdb->insert_id;

    // Insert fields linked to new component id
    $table_fields = $wpdb->prefix . 'recomb_fields';
    foreach ($fields as $field) {
        if (isset($field['id'])) unset($field['id']); // remove old field id
        $field['component_id'] = $new_component_id;
        $wpdb->insert($table_fields, $field);
    }

    return ['success' => true, 'new_component_id' => $new_component_id];
}
\add_action('rest_api_init', function() {
    register_rest_route('recomb/v1', '/import-component', [
        'methods' => 'POST',
        'callback' => 'recomb_import_component',
        'permission_callback' => function() {
            return current_user_can('edit_posts');
        }
    ]);
});
