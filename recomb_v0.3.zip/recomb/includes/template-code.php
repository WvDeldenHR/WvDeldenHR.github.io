<?php
function recomb_render_template_tags(string $template, int $post_id): string {
    global $wpdb;
    $meta = get_post_meta($post_id);
    $table = $wpdb->prefix . 'recomb_metabox';
// Add commentMore actions
    // Build a structure from the saved rows:
    $rows = $wpdb->get_results($wpdb->prepare("
        SELECT c.component_name, f.field_name, data.*
        FROM $table AS data
        INNER JOIN {$wpdb->prefix}recomb_components AS c ON data.component_id = c.id
        INNER JOIN {$wpdb->prefix}recomb_fields AS f ON data.field_id = f.id
        WHERE post_id = %d
    ", $post_id), ARRAY_A);

    $components = []; 
    foreach ($rows as $r) {
        $components[$r['component_name']][$r['group_index']][$r['field_name']] = maybe_unserialize($r['value']);
    }

    return preg_replace_callback('/\{(\w+)\}([\s\S]*?)\{\/\1\}/', function($m) use ($components) {
        [$all, $compName, $inner] = $m;
        if (!isset($components[$compName])) return '';
        $out = '';
        foreach ($components[$compName] as $group) {
            $temp = $inner;
            foreach ($group as $f => $v) {
                $temp = str_replace("{" . $f . "}", esc_html($v), $temp);
            }
            $out .= $temp;
        }
        return $out;
    }, $template);
}


// In your plugin's main file
add_action('template_redirect', function () {
    // Only on frontend, not admin or AJAX
    if (is_admin() || defined('DOING_AJAX') && DOING_AJAX) return;

    // Buffer the output
    ob_start(function ($html) {
        if (is_singular()) {
            $post_id = get_the_ID();
            $html = recomb_render_template_tags($html, $post_id);
        }
        return $html;
    });
});





add_action('rest_api_init', function () {
    register_rest_route('recomb/v1', '/extract-all-templates', [
        'methods' => 'GET',
        'callback' => 'recomb_extract_all_templates',
        'permission_callback' => '__return_true',
    ]);
});

function recomb_extract_all_templates() {
    $template_dir = get_stylesheet_directory() . '/templates/';
    if (!is_dir($template_dir)) {
        return new WP_Error('not_found', 'Templates directory not found.', ['status' => 404]);
    }

    $components = [];

    // Get all .html files inside templates/
    $files = glob($template_dir . '*.html');

    foreach ($files as $file) {
        $template_contents = file_get_contents($file);
        if (!$template_contents) {
            continue; // skip if unable to read file
        }

        // Regex to match all {component} ... {/component} blocks
        preg_match_all('/\{(\w+)\}(.*?)\{\/\1\}/s', $template_contents, $matches, PREG_SET_ORDER);

        foreach ($matches as $match) {
            $component_name = $match[1];
            $template_code = '{' . $component_name . '}' . $match[2] . '{/' . $component_name . '}';

            // To avoid duplicates, overwrite or keep last found
            $components[$component_name] = [
                'component_name' => $component_name,
                'template_code' => $template_code,
                'source_file' => basename($file), // optional: include filename for debugging
            ];
        }
    }

    // Return components as indexed array (not associative)
    return array_values($components);
}


add_action('rest_api_init', function () {
    register_rest_route('recomb/v1', '/get-all-components', [
        'methods' => 'GET',
        'callback' => 'recomb_get_all_components',
        'permission_callback' => function() {
            return current_user_can('edit_posts'); // or '__return_true' if no auth needed
        },
    ]);
});

function recomb_get_all_components() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'recomb_components';

    $results = $wpdb->get_results("SELECT component_name, template_code FROM $table_name", ARRAY_A);

    return $results ?: [];
}


add_action('rest_api_init', function () {
    register_rest_route('recomb/v1', '/sync-template', [
        'methods' => 'POST',
        'callback' => 'recomb_sync_template_callback',
        'permission_callback' => function () {
            return current_user_can('edit_posts'); // adjust capability as needed
        },
    ]);
});
function recomb_sync_template_callback( WP_REST_Request $request ) {
    $component_name = $request->get_param('component_name');
    $template_code = $request->get_param('template_code');

    if ( ! $component_name || ! $template_code ) {
        return new WP_Error('missing_param', 'Missing component_name or template_code', ['status' => 400]);
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'recomb_components'; // your components table name

    // Check if component exists
    $component = $wpdb->get_row( $wpdb->prepare(
        "SELECT * FROM $table_name WHERE component_name = %s",
        $component_name
    ) );

    if ( $component ) {
        // Update template_code for existing component
        $updated = $wpdb->update(
            $table_name,
            [ 'template_code' => $template_code ],
            [ 'component_name' => $component_name ],
            [ '%s' ],
            [ '%s' ]
        );
        if ( $updated === false ) {
            return new WP_Error('db_error', 'Failed to update component template', ['status' => 500]);
        }
    } else {
        // Insert new component record
        $inserted = $wpdb->insert(
            $table_name,
            [
                'component_name' => $component_name,
                'template_code' => $template_code,
            ],
            [ '%s', '%s' ]
        );
        if ( ! $inserted ) {
            return new WP_Error('db_error', 'Failed to insert component template', ['status' => 500]);
        }
    }

    return [ 'success' => true ];
}
