<?php
add_action('rest_api_init', function () {
    register_rest_route('recomb/v1', '/components-with-fields', [
        'methods' => 'GET',
        'callback' => 'recomb_get_components_with_fields',
        'permission_callback' => function() {
            return current_user_can('edit_posts');
        },
    ]);
});

function recomb_get_components_with_fields() {
    global $wpdb;
    $components_table = $wpdb->prefix . 'recomb_components';
    $fields_table = $wpdb->prefix . 'recomb_fields';

    $components = $wpdb->get_results("SELECT * FROM $components_table", ARRAY_A);

    foreach ($components as &$component) {
        $fields = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $fields_table WHERE component_id = %d",
            $component['id']
        ), ARRAY_A);
        $component['fields'] = $fields;
    }

    return $components;
}
