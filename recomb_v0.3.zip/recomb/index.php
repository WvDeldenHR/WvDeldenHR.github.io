<?php
/**
    * Plugin Name:  ReComb
    * Description:  Recomb: Reusable Component Builder for WordPress
    * Version:      0.2.1
    * Author:       ReComb
    * License:      GPL-2.0-or-later
    * Text Domain:  recomb
*/


/* --------------------------------------------------
    Includes
-------------------------------------------------- */
require_once plugin_dir_path(__FILE__) . 'includes/db.php';
require_once plugin_dir_path(__FILE__) . 'includes/api.php';
require_once plugin_dir_path(__FILE__) . 'includes/post-types.php';
require_once plugin_dir_path(__FILE__) . 'includes/template-code.php';
require_once plugin_dir_path(__FILE__) . 'includes/metabox.php';
require_once plugin_dir_path(__FILE__) . 'includes/export.php';
require_once plugin_dir_path(__FILE__) . 'includes/import.php';

// Create database when plugin is activated
register_activation_hook(__FILE__, 'recomb_create_database_tables');


/* --------------------------------------------------
    Admin Menu
-------------------------------------------------- */
function recomb_admin_menu(){
    add_menu_page(
        __('ReComb', 'recomb'),
        __('ReComb', 'recomb'),
        'manage_options',
        'recomb',
        'recomb_render_app',
        plugins_url('src/assets/static/icons/icon-recomb.svg', __FILE__),
    );

    add_submenu_page(
        'recomb',
        __('Create Component', 'recomb'),
        __('Create Component', 'recomb'),
        'manage_options',
        'recomb_create_component',
        'recomb_render_app'
    );

    add_submenu_page(
        'recomb',
        __('Settings', 'recomb'),
        __('Settings', 'recomb'),
        'manage_options',
        'recomb_settings',
        'recomb_render_app'
    );

    add_submenu_page(
        null,
        __('Edit Component', 'recomb'),
        __('Edit Component', 'recomb'),
        'manage_options',
        'recomb_edit_component',
        'recomb_render_app'
    );
}
add_action('admin_menu', 'recomb_admin_menu');


// Render React App
function recomb_render_app() {
    echo '<div id="root" data-page="' . esc_attr($_GET['page']) . '"></div>';
}


/* --------------------------------------------------
    Enqeue Scripts and Styles for Admin UI
-------------------------------------------------- */
function recomb_enqueue_scripts( $admin_page) {

    // Add recomb classes to WordPress admin body
    add_filter('admin_body_class', function( $classes ) {
        if (isset($_GET['page']) && strpos($_GET['page'], 'recomb') === 0) {
            $classes .= ' recomb recomb_body';
        }
        return $classes;
    });

    // Load asset metadata from build tool
    $asset_file = plugin_dir_path( __FILE__ ) . 'build/index.asset.php';
    if ( ! file_exists( $asset_file )) {
        return;
    }
    $asset = include $asset_file;

    // Enqueue JS with dependencies and version from asset file
    wp_enqueue_script(
        'recomb-script',
        plugins_url( 'build/index.js', __FILE__ ),
        $asset['dependencies'],
        $asset['version'],
        array(
            'in_footer' => true,
        )
    );

    // Fetch Post Types
    $filtered_post_types = recomb_get_filtered_post_types();

    // Pass dynamic data to JS
    wp_localize_script('recomb-script', 'ReCombData', [
        'nonce'     => wp_create_nonce('wp_rest'),
        'adminUrl'  => admin_url('admin.php'),
        'id' => isset($_GET['id']) ? intval($_GET['id']) : 0,
        'postTypes' => $filtered_post_types,
        'postId' => get_the_ID(),
    ]);

    // Determine correct CSS file based on language direction (RTL or LTR)
    $css_handle = is_rtl() ? 'recomb-style-rtl' : 'recomb-style';
    $css_file = is_rtl() ? 'build/index-rtl.css' : 'build/index.css';

    // Enqueue plugin styles
    wp_enqueue_style(
        $css_handle,
        plugins_url( $css_file, __FILE__ ),
        array_filter(
            $asset['dependencies'],
            function($style) {
                return wp_style_is($style, 'registered');
            }
        ),
        $asset['version'],
    );
}
add_action('admin_enqueue_scripts', 'recomb_enqueue_scripts');
